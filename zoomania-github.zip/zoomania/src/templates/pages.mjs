import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import path from 'node:path';
import { catSVG } from '../lib/cat.mjs';
import { breeds, DIMENSIONS, filterLabels } from '../data/breeds.mjs';
import { questions, dimensionLabels } from '../data/quiz.mjs';
import { esc } from './layout.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const hasPhoto = (slug) => fs.existsSync(path.join(ROOT, 'assets/photos', `${slug}.jpg`));

// Small line icons (decorative)
const ICON = {
  nutrition: '<path d="M4 13h16a8 8 0 0 1-16 0Z"/><path d="M9 9c0-2 2-2 2-4M14 9c0-2 2-2 2-4"/>',
  hydration: '<path d="M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11Z"/>',
  grooming: '<path d="M5 19 15 9"/><rect x="13" y="3" width="8" height="8" rx="2" transform="rotate(45 17 7)"/>',
  litter: '<path d="M3 10h18l-2 9H5Z"/><path d="M7 10V7h10v3"/>',
  enrichment: '<circle cx="12" cy="12" r="7"/><path d="M5 12c4-2 10-2 14 0M12 5c-2 4-2 10 0 14"/>',
  checkups: '<path d="M6 3v6a4 4 0 0 0 8 0V3"/><path d="M10 13v3a4 4 0 0 0 8 0v-2"/><circle cx="18" cy="12" r="2"/>',
  vaccination: '<path d="m18 2 4 4M15 5l4 4M4 20l3-3M7 17l-2-2 9-9 4 4-9 9Z"/>',
  neutering: '<path d="M12 21s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.5-7 10-7 10Z"/>',
  warning: '<path d="M12 3 2 20h20Z"/><path d="M12 10v4M12 17h.01"/>',
  senior: '<path d="M20 14A8 8 0 1 1 10 4a6 6 0 0 0 10 10Z"/>',
  safety: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6Z"/><path d="m9 12 2 2 4-4"/>',
  paw: '<circle cx="7" cy="9" r="2"/><circle cx="12" cy="6" r="2"/><circle cx="17" cy="9" r="2"/><path d="M8 17c0-3 2-5 4-5s4 2 4 5-2 3-4 3-4 0-4-3Z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5 19 19M5 19l1.5-1.5M17.5 6.5 19 5"/>',
  study: '<path d="M2 9l10-5 10 5-10 5Z"/><path d="M6 11v5c3 2 9 2 12 0v-5"/><path d="M22 9v6"/>',
  path: '<circle cx="6" cy="19" r="2"/><circle cx="18" cy="5" r="2"/><path d="M8 19h8a3 3 0 0 0 0-6H8a3 3 0 0 1 0-6h8"/>',
  code: '<path d="m8 8-5 4 5 4M16 8l5 4-5 4M14 5l-4 14"/>',
  heart: '<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10Z"/>',
  link: '<path d="M10 14a4 4 0 0 0 6 0l3-3a4 4 0 0 0-6-6l-1 1"/><path d="M14 10a4 4 0 0 0-6 0l-3 3a4 4 0 0 0 6 6l1-1"/>'
};
const PAW = '<svg viewBox="0 0 24 24" focusable="false"><circle cx="6.5" cy="9" r="2.2"/><circle cx="12" cy="6" r="2.2"/><circle cx="17.5" cy="9" r="2.2"/><path d="M7.5 17c0-3.2 2.2-5.5 4.5-5.5s4.5 2.3 4.5 5.5c0 2-1.8 2.8-4.5 2.8S7.5 19 7.5 17Z"/></svg>';
export const icon = (k) => `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${ICON[k] || ICON.paw}</svg>`;

export function breedVisual(b, t, { lazy = true, cls = '' } = {}) {
  const name = b[t.lang].name;
  if (hasPhoto(b.slug)) {
    return `<img class="breed-photo ${cls}" src="../assets/photos/${b.slug}.jpg" alt="${esc(t.lang === 'en' ? `${name} cat` : `قطة ${name}`)}" width="480" height="400" ${lazy ? 'loading="lazy" decoding="async"' : ''}>`;
  }
  return `<div class="breed-illus ${cls}">${catSVG(b.look, { title: t.quiz.photoAlt(name) })}</div>`;
}

const heroCats = [
  { fur: '#FFF4DE', shade: '#E9CFB4', accent: '#D8B898', eye: '#C98A3B', type: 'longhair', face: 'flat' },
  { fur: '#A9B1BC', shade: '#76808C', accent: '#5E6773', eye: '#D98E2B', type: 'plush', face: 'round' },
  { fur: '#F2B07E', shade: '#C77B4A', accent: '#9A5530', eye: '#7FA33A', type: 'tabby-long', face: 'tufted' }
];

const sectionHead = (kicker, h, p, id, level = 2) => `<div class="section-head">
  <p class="kicker">${esc(kicker)}</p>
  <h${level} id="${id}">${esc(h)}</h${level}>
  ${p ? `<p class="lead">${esc(p)}</p>` : ''}
</div>`;

/* ---------------- HOME ---------------- */
export function homeBody(t) {
  const h = t.home;
  const featured = ['ragdoll', 'bengal', 'british-shorthair', 'siamese'].map((s) => breeds.find((b) => b.slug === s));
  return `
<section class="hero" aria-labelledby="hero-title">
  <div class="container hero-grid">
    <div class="hero-copy reveal">
      <p class="kicker">${esc(h.eyebrow)}</p>
      <h1 id="hero-title" class="split-words">${h.h1.split(' ').map((w, i) => `<span class="w" style="--i:${i}">${esc(w)}</span>`).join(' ')}</h1>
      <p class="tagline">${esc(h.tagline)}</p>
      <p class="lead">${esc(h.lead)}</p>
      <div class="btn-row">
        <a class="btn btn-primary" href="quiz.html">${esc(h.cta1)} <span class="btn-arrow" aria-hidden="true">→</span></a>
        <a class="btn btn-ghost" href="breeds.html">${esc(h.cta2)}</a>
      </div>
      <dl class="hero-stats">${h.stats.map(([n, l]) => `<div><dt>${esc(l)}</dt><dd data-count-to="${n}">${n}</dd></div>`).join('')}</dl>
    </div>
    <div class="hero-stage" role="img" aria-label="${esc(h.heroAlt)}" data-cat-stage>
      <div class="stage-blob" aria-hidden="true"></div>
      <div class="stage-arch" aria-hidden="true"></div>
      <div class="podium p1" aria-hidden="true"></div><div class="podium p2" aria-hidden="true"></div><div class="podium p3" aria-hidden="true"></div>
      ${heroCats.map((c, i) => `<div class="hero-cat hc${i + 1}" data-cat>${catSVG(c, { decorative: true })}</div>`).join('')}
      <span class="float-heart fh1" aria-hidden="true">♥</span><span class="float-heart fh2" aria-hidden="true">♥</span>
      <div class="paw-drift" aria-hidden="true">${[1, 2, 3, 4, 5].map((i) => `<span class="pd pd${i}">${PAW}</span>`).join('')}</div>
      <div class="hero-sparkles" aria-hidden="true"><i></i><i></i><i></i></div>
    </div>
  </div>
</section>

<section class="section" aria-labelledby="welcome">
  <div class="container">
    ${sectionHead(h.welcome.kicker, h.welcome.h2, h.welcome.p, 'welcome')}
    <div class="grid-3 stagger">
      ${h.welcome.cards.map(([a, b], i) => `<article class="card soft reveal"><span class="card-icon">${icon(['paw', 'neutering', 'enrichment'][i])}</span><h3>${esc(a)}</h3><p>${esc(b)}</p></article>`).join('')}
    </div>
  </div>
</section>

<section class="section tint-cream" aria-labelledby="featured">
  <div class="container">
    <div class="section-head split">
      <div><p class="kicker">${esc(h.featured.kicker)}</p><h2 id="featured">${esc(h.featured.h2)}</h2><p class="lead">${esc(h.featured.p)}</p></div>
      <a class="btn btn-ghost" href="breeds.html#breeds">${esc(h.featured.all)}</a>
    </div>
    <ul class="grid-4 plain stagger">
      ${featured.map((b) => `<li class="reveal"><a class="preview-card" href="breeds.html#breed-${b.slug}">
        ${breedVisual(b, t)}
        <span class="preview-body"><span class="preview-name">${esc(b[t.lang].name)}</span><span class="preview-temp">${esc(b[t.lang].temperament)}</span>
        <span class="preview-link">${esc(h.featured.view)} <span aria-hidden="true" class="flip-rtl">→</span></span></span>
      </a></li>`).join('')}
    </ul>
  </div>
</section>

<section class="section" aria-labelledby="quiz-promo">
  <div class="container">
    <div class="promo reveal">
      <div class="promo-copy">
        <p class="kicker">${esc(h.quizPromo.kicker)}</p>
        <h2 id="quiz-promo">${esc(h.quizPromo.h2)}</h2>
        <p>${esc(h.quizPromo.p)}</p>
        <a class="btn btn-primary" href="quiz.html">${esc(h.quizPromo.cta)} <span class="btn-arrow" aria-hidden="true">→</span></a>
        <p class="small">${esc(h.quizPromo.note)}</p>
      </div>
      <div class="promo-art" aria-hidden="true">
        <div class="promo-bubble">?</div>
        <div class="promo-cat" data-cat>${catSVG(breeds[3].look, { decorative: true })}</div>
      </div>
    </div>
  </div>
</section>

<section class="section tint-peach" aria-labelledby="care-preview">
  <div class="container">
    ${sectionHead(h.care.kicker, h.care.h2, h.care.p, 'care-preview')}
    <div class="grid-4 stagger">
      ${h.care.items.map(([a, b], i) => `<article class="card mini reveal"><span class="card-icon">${icon(['hydration', 'nutrition', 'enrichment', 'checkups'][i])}</span><h3>${esc(a)}</h3><p>${esc(b)}</p></article>`).join('')}
    </div>
    <p class="center"><a class="btn btn-ghost" href="breeds.html#cat-care">${esc(h.care.cta)}</a></p>
  </div>
</section>

<section class="section" aria-labelledby="dubai-preview">
  <div class="container">
    <div class="dubai-band reveal">
      <div class="skyline" aria-hidden="true">${skyline()}<div class="band-cat" data-cat>${catSVG(breeds[0].look, { decorative: true })}</div></div>
      <div class="dubai-copy">
        <p class="kicker">${esc(h.dubai.kicker)}</p>
        <h2 id="dubai-preview">${esc(h.dubai.h2)}</h2>
        <p>${esc(h.dubai.p)}</p>
        <ul class="chips">${h.dubai.chips.map((c) => `<li>${esc(c)}</li>`).join('')}</ul>
        <a class="btn btn-primary" href="dubai.html">${esc(h.dubai.cta)} <span class="btn-arrow" aria-hidden="true">→</span></a>
      </div>
    </div>
  </div>
</section>

<section class="section tint-blush about" id="about" aria-labelledby="about-title">
  <div class="container about-grid">
    <figure class="portrait reveal">
      <div class="portrait-blob" aria-hidden="true"></div>
      <div class="portrait-dots" aria-hidden="true"></div>
      <div class="portrait-orbit" aria-hidden="true"><span>${PAW}</span><span>♥</span><span>${PAW}</span></div>
      <div class="portrait-ring">
        <div class="portrait-frame">
          <img class="portrait-photo" src="../assets/images/atrin.jpg" alt="${esc(h.about.portraitAlt)}" width="640" height="800" loading="lazy" decoding="async">
        </div>
      </div>
      <span class="portrait-badge b1" aria-hidden="true">${icon('heart')}${esc(h.about.badge)}</span>
      <span class="portrait-badge b2" aria-hidden="true">${icon('code')}${esc(h.about.badge2)}</span>
      <img class="portrait-sticker" src="../assets/brand/icon-192.png" alt="" width="96" height="96" loading="lazy" decoding="async">
      <figcaption>${esc(h.about.portrait)}</figcaption>
    </figure>
    <div class="about-copy reveal">
      <p class="kicker">${esc(h.about.kicker)}</p>
      <h2 id="about-title">${esc(h.about.h2)}</h2>
      <p class="about-hello">${esc(h.about.intro)} <span class="wave" aria-hidden="true">👋</span></p>
      ${h.about.paras.map((p) => `<p>${esc(p)}</p>`).join('')}
      <blockquote class="about-quote"><p>${esc(h.about.quote)}</p><footer>${esc(h.about.sign)}</footer></blockquote>
    </div>
  </div>

  <div class="container about-more">
    <h3 class="about-sub">${esc(h.about.factsTitle)}</h3>
    <dl class="facts-grid stagger">
      ${h.about.facts.map(([k, a, b]) => `<div class="fact card reveal"><dt><span class="card-icon">${icon(k)}</span><span>${esc(a)}</span></dt><dd>${esc(b)}</dd></div>`).join('')}
    </dl>

    <div class="about-two">
      <div>
        <h3 class="about-sub">${esc(h.about.whyTitle)}</h3>
        <ul class="why-list stagger">
          ${h.about.why.map(([a, b, u], i) => `<li class="reveal"><a class="why-card" href="${u}"><span class="why-num" aria-hidden="true">${i + 1}</span><span><strong>${esc(a)}</strong><span>${esc(b)}</span></span><span class="flip-rtl why-arrow" aria-hidden="true">→</span></a></li>`).join('')}
        </ul>
      </div>
      <div>
        <h3 class="about-sub">${esc(h.about.journeyTitle)}</h3>
        <ol class="timeline" data-timeline>
          ${h.about.journey.map(([a, b], i) => `<li class="reveal${i === h.about.journey.length - 1 ? ' is-next' : ''}"><h4>${esc(a)}</h4><p>${esc(b)}</p></li>`).join('')}
        </ol>
      </div>
    </div>
  </div>

  <div class="container" id="mission">
    <h3 class="mission-title">${esc(h.mission.h3)}</h3>
    <ol class="mission-list stagger">
      ${h.mission.items.map(([a, b], i) => `<li class="card reveal"><span class="mission-num" aria-hidden="true">0${i + 1}</span><h4>${esc(a)}</h4><p>${esc(b)}</p></li>`).join('')}
    </ol>
  </div>
</section>`;
}

function skyline() {
  return `<svg viewBox="0 0 600 160" preserveAspectRatio="xMidYMax slice" focusable="false">
    <circle cx="470" cy="62" r="34" fill="#FFF4DE"/>
    <g fill="#FFCED8"><rect x="20" y="96" width="44" height="64" rx="4"/><rect x="70" y="80" width="30" height="80" rx="4"/><rect x="110" y="104" width="50" height="56" rx="4"/>
    <path d="M240 160 L250 40 L254 10 L258 40 L268 160 Z"/><rect x="290" y="88" width="36" height="72" rx="4"/>
    <path d="M340 160 Q360 70 400 60 L400 160 Z"/><rect x="420" y="100" width="40" height="60" rx="4"/><rect x="520" y="92" width="34" height="68" rx="4"/><rect x="560" y="110" width="40" height="50" rx="4"/></g>
    <g fill="#FFDDDD"><rect x="170" y="112" width="40" height="48" rx="4"/><rect x="470" y="118" width="44" height="42" rx="4"/></g>
  </svg>`;
}

/* ---------------- BREEDS + CARE ---------------- */
export function breedsBody(t) {
  const p = t.breedsPage, L = filterLabels[t.lang], c = t.care;
  const facets = [['coat', ['long', 'short', 'hairless']], ['activity', ['low', 'moderate', 'high']], ['size', ['medium', 'large']]];
  const bar = (v) => `<span class="meter" aria-hidden="true"><span style="--v:${v / 4}"></span></span>`;
  const dimL = dimensionLabels[t.lang];

  const cards = breeds.map((b) => {
    const d = b[t.lang];
    return `<li class="breed-card reveal" id="breed-${b.slug}" data-coat="${b.coat}" data-activity="${b.activity}" data-size="${b.size}">
  <article aria-labelledby="bn-${b.slug}">
    <div class="breed-media">${breedVisual(b, t)}</div>
    <div class="breed-body">
      <h3 id="bn-${b.slug}">${esc(d.name)}</h3>
      <p>${esc(d.intro)}</p>
      <ul class="tag-row" aria-label="${esc(p.filterTitle)}">
        <li>${esc(L.coat)}: ${esc(L[b.coat])}</li><li>${esc(L.activity)}: ${esc(L[b.activity])}</li><li>${esc(L.size)}: ${esc(L[b.size])}</li>
      </ul>
      <details class="breed-more">
        <summary>${t.lang === 'en' ? 'Full profile' : 'الملف الكامل'}</summary>
        <dl class="facts">
          <div><dt>${esc(p.fields.temperament)}</dt><dd>${esc(d.temperament)}</dd></div>
          <div><dt>${esc(p.fields.coat)}</dt><dd>${esc(d.coatText)}</dd></div>
          <div><dt>${esc(p.fields.grooming)}</dt><dd>${esc(d.grooming)}</dd></div>
          <div><dt>${esc(p.fields.activity)}</dt><dd>${esc(d.activityText)}</dd></div>
          <div><dt>${esc(p.fields.size)}</dt><dd>${esc(d.sizeText)}</dd></div>
          <div class="health${b.slug === 'scottish-fold' ? ' warn' : ''}"><dt>${b.slug === 'scottish-fold' ? icon('warning') : ''}${esc(p.fields.health)}</dt><dd>${esc(d.health)}</dd></div>
        </dl>
        <h4 class="traits-h">${esc(p.traits)}</h4>
        <dl class="traits">${DIMENSIONS.map((k) => `<div><dt>${esc(dimL[k])}</dt><dd>${bar(b.profile[k])}<span class="num">${b.profile[k]}</span></dd></div>`).join('')}</dl>
      </details>
      <button class="btn btn-small btn-ghost" type="button" data-compare-add="${b.slug}">${esc(p.compareBtn)}</button>
    </div>
  </article>
</li>`;
  }).join('');

  const compareData = Object.fromEntries(breeds.map((b) => [b.slug, {
    name: b[t.lang].name, temperament: b[t.lang].temperament, coat: b[t.lang].coatText, grooming: b[t.lang].grooming,
    activity: b[t.lang].activityText, size: b[t.lang].sizeText, health: b[t.lang].health, profile: b.profile
  }]));
  const opts = (sel) => breeds.map((b) => `<option value="${b.slug}"${b.slug === sel ? ' selected' : ''}>${esc(b[t.lang].name)}</option>`).join('');
  const rows = ['temperament', 'coat', 'grooming', 'activity', 'size', 'health'];
  const cell = (slug, k) => esc(compareData[slug][k]);

  return `
<section class="page-hero" aria-labelledby="breeds-title">
  <div class="container page-hero-grid">
    <div>
      <p class="kicker">${esc(p.kicker)}</p>
      <h1 id="breeds-title">${esc(p.h1)}</h1>
      <p class="lead">${esc(p.lead)}</p>
      <nav class="jump" aria-label="${t.lang === 'en' ? 'On this page' : 'في هذه الصفحة'}">
        <a href="#breeds">${esc(p.h1)}</a><a href="#compare-title">${esc(p.compareH2)}</a><a href="#cat-care">${esc(c.kicker)}</a>
      </nav>
    </div>
    <div class="page-hero-cat" aria-hidden="true" data-cat>${catSVG(breeds[1].look, { decorative: true })}</div>
  </div>
</section>

<section class="section" id="breeds" aria-labelledby="breeds-list-title">
  <div class="container">
    <h2 id="breeds-list-title" class="visually-hidden">${esc(p.h1)}</h2>
    <form class="filters" data-filters aria-labelledby="filter-title">
      <h3 id="filter-title" class="filters-title">${esc(p.filterTitle)}</h3>
      ${facets.map(([k, vals]) => `<fieldset><legend>${esc(L[k])}</legend>
        <label class="seg"><input type="radio" name="${k}" value="all" checked><span>${esc(L.all)}</span></label>
        ${vals.map((v) => `<label class="seg"><input type="radio" name="${k}" value="${v}"><span>${esc(L[v])}</span></label>`).join('')}
      </fieldset>`).join('')}
      <div class="filter-foot"><p class="count" aria-live="polite"><strong data-count>${breeds.length}</strong> ${esc(p.results)}</p>
      <button type="reset" class="btn btn-small btn-ghost">${esc(p.reset)}</button></div>
    </form>
    ${hasPhoto('persian') ? '' : `<p class="small center photo-note">${esc(p.photoNote)}</p>`}
    <ul class="breed-grid plain" data-breed-grid>${cards}</ul>
  </div>
</section>

<section class="section tint-cream" aria-labelledby="compare-title">
  <div class="container">
    ${sectionHead(p.compareBtn, p.compareH2, p.compareP, 'compare-title')}
    <div class="compare" data-compare>
      <div class="compare-pickers">
        <label>${esc(p.compareA)}<select data-compare-a>${opts('persian')}</select></label>
        <span class="vs" aria-hidden="true">vs</span>
        <label>${esc(p.compareB)}<select data-compare-b>${opts('bengal')}</select></label>
      </div>
      <div class="table-wrap" tabindex="0" role="region" aria-label="${esc(p.compareCaption)}">
      <table class="compare-table">
        <caption class="visually-hidden">${esc(p.compareCaption)}</caption>
        <thead><tr><th scope="col"><span class="visually-hidden">${t.lang === 'en' ? 'Attribute' : 'الخاصية'}</span></th><th scope="col" data-col="a">${cell('persian', 'name')}</th><th scope="col" data-col="b">${cell('bengal', 'name')}</th></tr></thead>
        <tbody>
          ${rows.map((k) => `<tr><th scope="row">${esc(p.fields[k])}</th><td data-a="${k}">${cell('persian', k)}</td><td data-b="${k}">${cell('bengal', k)}</td></tr>`).join('')}
          ${DIMENSIONS.map((k) => `<tr class="dim"><th scope="row">${esc(dimL[k])}</th><td data-a-dim="${k}">${bar(compareData.persian.profile[k])} <span class="num">${compareData.persian.profile[k]}</span></td><td data-b-dim="${k}">${bar(compareData.bengal.profile[k])} <span class="num">${compareData.bengal.profile[k]}</span></td></tr>`).join('')}
        </tbody>
      </table>
      </div>
    </div>
  </div>
  <script type="application/json" id="compare-data">${JSON.stringify(compareData).replace(/</g, '\\u003c')}</script>
</section>

<section class="section care" id="cat-care" aria-labelledby="care-title" tabindex="-1">
  <div class="container">
    ${sectionHead(c.kicker, c.h2, c.lead, 'care-title')}
    <div class="care-grid stagger">
      ${c.topics.map(([k, h, body]) => `<article class="card care-card reveal" id="care-${k}"><span class="card-icon">${icon(k)}</span><h3>${esc(h)}</h3><p>${esc(body)}</p></article>`).join('')}
    </div>
    <div class="faq-wrap">
      <h3 class="faq-title">${esc(c.faqH3)}</h3>
      <div class="faq">${c.faq.map(([q, a]) => `<details><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join('')}</div>
    </div>
    <aside class="refs" aria-labelledby="refs-title">
      <h3 id="refs-title">${esc(c.refsH3)}</h3>
      <ul>${c.refs.map(([n, u]) => `<li><a href="${u}" rel="noopener" target="_blank">${esc(n)}<span class="visually-hidden"> ${t.lang === 'en' ? '(opens in a new tab)' : '(يفتح في علامة تبويب جديدة)'}</span></a></li>`).join('')}</ul>
      <p class="small">${esc(c.disclaimer)}</p>
    </aside>
  </div>
</section>`;
}

/* ---------------- QUIZ ---------------- */
export function quizBody(t) {
  const q = t.quiz;
  const data = {
    lang: t.lang,
    dims: DIMENSIONS,
    dimLabels: dimensionLabels[t.lang],
    questions: questions.map((x) => ({ q: x[t.lang], a: x.answers.map((a) => ({ t: a[t.lang], v: a.v })) })),
    breeds: breeds.map((b) => ({ slug: b.slug, name: b[t.lang].name, personality: b[t.lang].personality, temperament: b[t.lang].temperament, profile: b.profile, look: b.look, photo: hasPhoto(b.slug) })),
    s: {
      question: q.question, of: q.of, prev: q.prev, next: q.next, finish: q.finish, shared: q.shared, downloaded: q.downloaded, downloadFail: q.downloadFail,
      cardTitle: q.cardTitle, match: q.match, you: q.you, breed: q.breed, shareTpl: q.shareText('{b}', '{p}'), photoAlt: q.photoAlt('{b}'), site: 'zoomania'
    }
  };
  const portraits = breeds.map((b) => `<template id="portrait-${b.slug}">${breedVisual(b, t, { lazy: false })}</template>`).join('');
  return `
<section class="quiz-shell" aria-labelledby="quiz-title">
  <div class="container">
    <div class="quiz-intro" data-quiz-intro>
      <div class="quiz-intro-copy">
        <p class="kicker">${esc(q.kicker)}</p>
        <h1 id="quiz-title">${esc(q.h1)}</h1>
        <p class="lead">${esc(q.lead)}</p>
        <button class="btn btn-primary" type="button" data-quiz-start>${esc(q.start)} <span class="btn-arrow" aria-hidden="true">→</span></button>
        <details class="how"><summary>${esc(q.how)}</summary><p>${esc(q.howText)}</p></details>
      </div>
      <div class="quiz-companion" aria-hidden="true" data-cat>${catSVG(breeds[2].look, { decorative: true })}</div>
    </div>

    <div class="quiz-panel" data-quiz-panel hidden>
      <div class="quiz-top">
        <div class="quiz-mini-cat" aria-hidden="true" data-cat data-companion>${catSVG(breeds[2].look, { decorative: true })}</div>
        <div class="progress-wrap">
          <p class="progress-label" data-progress-label aria-live="polite"></p>
          <div class="progress" role="progressbar" aria-valuemin="1" aria-valuemax="10" aria-valuenow="1" data-progress><span></span></div>
        </div>
      </div>
      <form data-quiz-form>
        <fieldset class="question" data-question>
          <legend class="question-text" data-question-text tabindex="-1"></legend>
          <p class="visually-hidden">${esc(q.choose)}</p>
          <div class="answers" data-answers role="radiogroup"></div>
        </fieldset>
        <p class="small hint">${esc(q.keyboardHint)}</p>
        <div class="quiz-nav">
          <button class="btn btn-ghost" type="button" data-prev>${esc(q.prev)}</button>
          <button class="btn btn-primary" type="submit" data-next disabled>${esc(q.next)}</button>
        </div>
      </form>
    </div>

    <div class="quiz-result" data-quiz-result hidden tabindex="-1" aria-labelledby="result-name">
      <div class="result-hero">
        <div class="result-media" data-result-media></div>
        <div class="result-copy">
          <p class="kicker">${esc(q.resultKicker)}</p>
          <h2 id="result-name" data-result-name></h2>
          <div class="match"><span class="match-num" data-result-pct></span><span class="match-label">${esc(q.match)}</span></div>
          <p class="small match-note">${esc(q.matchNote)}</p>
          <p data-result-personality></p>
          <div class="btn-row">
            <a class="btn btn-primary" data-result-explore href="breeds.html">${esc(q.explore)}</a>
            <button class="btn btn-ghost" type="button" data-restart>${esc(q.restart)}</button>
          </div>
          <div class="btn-row secondary">
            <button class="btn btn-small btn-ghost" type="button" data-download>${esc(q.download)}</button>
            <button class="btn btn-small btn-ghost" type="button" data-share hidden>${esc(q.share)}</button>
            <button class="btn btn-small btn-ghost" type="button" data-copy>${esc(q.copy)}</button>
          </div>
          <p class="status" role="status" data-status></p>
        </div>
      </div>
      <div class="result-details">
        <div class="card">
          <h3>${esc(q.traitsH3)}</h3>
          <ul class="match-traits" data-result-traits></ul>
          <p class="small"><strong>${esc(q.runnersUp)}:</strong> <span data-result-runners></span></p>
        </div>
        <div class="card">
          <h3>${esc(q.explainH3)}</h3>
          <p class="small">${esc(q.explain)}</p>
          <div class="table-wrap" tabindex="0" role="region" aria-label="${esc(q.explainH3)}">
          <table class="score-table"><thead><tr><th scope="col"><span class="visually-hidden">${t.lang === 'en' ? 'Dimension' : 'البُعد'}</span></th><th scope="col">${esc(q.you)}</th><th scope="col" data-result-breed-col>${esc(q.breed)}</th></tr></thead><tbody data-result-table></tbody></table>
          </div>
        </div>
      </div>
      <p class="center small"><a href="dubai.html#adoption">${esc(q.welfare)}</a></p>
    </div>
    <div class="decor-cat" aria-hidden="true" data-decor></div>
  </div>
  ${portraits}
  <script type="application/json" id="quiz-data">${JSON.stringify(data).replace(/</g, '\\u003c')}</script>
</section>`;
}

/* ---------------- DUBAI ---------------- */
export function dubaiBody(t) {
  const d = t.dubai;
  const ext = t.lang === 'en' ? '(opens in a new tab)' : '(يفتح في علامة تبويب جديدة)';
  const a = (u, label) => `<a href="${u}" rel="noopener" target="_blank">${esc(label)}<span class="visually-hidden"> ${ext}</span></a>`;
  const toc = [['lifestyle', d.s1.h2], ['hot-weather', d.s2.h2], ['adoption', d.s3.h2], ['welfare', d.s4.h2], ['rules', d.s5.h2], ['dubai-faq', d.s6.h2]];
  return `
<section class="page-hero dubai-hero" aria-labelledby="dubai-title">
  <div class="container page-hero-grid">
    <div>
      <p class="kicker">${esc(d.kicker)}</p>
      <h1 id="dubai-title">${esc(d.h1)}</h1>
      <p class="lead">${esc(d.lead)}</p>
      <p class="small">${esc(d.updated)}</p>
    </div>
    <div class="dubai-hero-art" aria-hidden="true">${skyline()}<div class="dubai-cat" data-cat>${catSVG(breeds[5].look, { decorative: true })}</div></div>
  </div>
</section>

<div class="container editorial">
  <nav class="toc" aria-labelledby="toc-title">
    <h2 id="toc-title" class="toc-title">${esc(d.toc)}</h2>
    <ol>${toc.map(([id, h]) => `<li><a href="#${id}">${esc(h)}</a></li>`).join('')}</ol>
  </nav>

  <div class="editorial-body">
    <section id="lifestyle" class="ed-section reveal" aria-labelledby="lifestyle-h">
      <h2 id="lifestyle-h">${esc(d.s1.h2)}</h2>
      ${d.s1.p.map((x) => `<p>${esc(x)}</p>`).join('')}
      <div class="grid-3">${d.s1.cards.map(([h, p], i) => `<article class="card mini"><span class="card-icon">${icon(['paw', 'safety', 'link'][i])}</span><h3>${esc(h)}</h3><p>${esc(p)}</p></article>`).join('')}</div>
    </section>

    <section id="hot-weather" class="ed-section reveal" aria-labelledby="hot-h">
      <h2 id="hot-h">${icon('sun')} ${esc(d.s2.h2)}</h2>
      <p>${esc(d.s2.p)}</p>
      <ul class="tips">${d.s2.tips.map(([h, p]) => `<li><h3>${esc(h)}</h3><p>${esc(p)}</p></li>`).join('')}</ul>
    </section>

    <section id="adoption" class="ed-section reveal" aria-labelledby="adopt-h">
      <h2 id="adopt-h">${esc(d.s3.h2)}</h2>
      ${d.s3.p.map((x) => `<p>${esc(x)}</p>`).join('')}
      <div class="card checklist"><h3>${esc(d.s3.checklistH3)}</h3><ul>${d.s3.checklist.map((x) => `<li>${esc(x)}</li>`).join('')}</ul></div>
    </section>

    <section id="welfare" class="ed-section reveal" aria-labelledby="welfare-h">
      <h2 id="welfare-h">${esc(d.s4.h2)}</h2>
      <p>${esc(d.s4.p)}</p>
      <div class="grid-2">${d.s4.items.map(([h, p, u, src]) => `<article class="card"><h3>${esc(h)}</h3><p>${esc(p)}</p><p class="small source">${icon('link')} ${a(u, src)}</p></article>`).join('')}</div>
    </section>

    <section id="rules" class="ed-section reveal" aria-labelledby="rules-h">
      <h2 id="rules-h">${esc(d.s5.h2)}</h2>
      <p>${esc(d.s5.p)}</p>
      <dl class="rules">${d.s5.rules.map(([h, p]) => `<div><dt>${esc(h)}</dt><dd>${esc(p)}</dd></div>`).join('')}</dl>
      <div class="card links-card">
        <h3>${esc(d.s5.linksH3)}</h3>
        <ul>${d.s5.links.map(([n, u]) => `<li>${a(u, n)}</li>`).join('')}</ul>
        <p class="small">${esc(d.s5.phone)}</p>
        <p class="small">${esc(d.s5.disclaimer)}</p>
      </div>
    </section>

    <section id="dubai-faq" class="ed-section reveal" aria-labelledby="dfaq-h">
      <h2 id="dfaq-h">${esc(d.s6.h2)}</h2>
      <div class="faq">${d.s6.faq.map(([q, ans]) => `<details><summary>${esc(q)}</summary><p>${esc(ans)}</p></details>`).join('')}</div>
    </section>

    <!-- Future Dubai guides: add new <section class="ed-section"> blocks here and a matching TOC entry. -->
    <p class="small more-note">${esc(d.more)}</p>
  </div>
</div>`;
}
