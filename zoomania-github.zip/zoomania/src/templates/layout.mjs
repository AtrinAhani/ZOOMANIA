
export const PAGES = ['index', 'breeds', 'quiz', 'dubai'];
const NAV_KEY = { index: 'home', breeds: 'breeds', quiz: 'quiz', dubai: 'dubai' };

export const esc = (s = '') => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

export function logo(t, { footer = false } = {}) {
  // Official ZOOMANIA logo (Latin wordmark in both languages). Footer uses the light variant.
  return `<a class="brand" href="index.html" aria-label="zoomania — ${esc(t.nav.home)}">
    <img class="brand-logo" src="../assets/brand/${footer ? 'logo-light' : 'logo'}.png" alt="" width="600" height="151" decoding="async">
  </a>`;
}

function langSwitch(t, page) {
  return `<a class="lang-switch" href="../${t.other}/${page}.html" hreflang="${t.other}" lang="${t.other}" aria-label="${esc(t.switchAria)}">
    <span aria-hidden="true" class="lang-dot"></span><span class="${t.lang === 'en' ? 'lang-ar' : ''}">${t.switchLabel}</span></a>`;
}

export function header(t, page) {
  const links = PAGES.map((p) => {
    const cur = p === page ? ' aria-current="page"' : '';
    return `<li><a href="${p}.html"${cur}>${esc(t.nav[NAV_KEY[p]])}</a></li>`;
  }).join('');
  return `<a class="skip-link" href="#main">${esc(t.skip)}</a>
<header class="site-header" data-header>
  <div class="container header-inner">
    ${logo(t)}
    <nav class="main-nav" aria-label="${esc(t.nav.primary)}">
      <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="nav-list" data-open-label="${esc(t.nav.menu)}" data-close-label="${esc(t.nav.close)}">
        <span class="nav-toggle-bars" aria-hidden="true"><span></span><span></span><span></span></span>
        <span class="nav-toggle-text">${esc(t.nav.menu)}</span>
      </button>
      <ul id="nav-list" class="nav-list">${links}</ul>
    </nav>
    ${langSwitch(t, page)}
  </div>
</header>`;
}

export function footer(t, page) {
  const year = new Date().getFullYear();
  const f = t.footer;
  return `<footer class="site-footer">
  <div class="container footer-grid">
    <div class="footer-brand">
      ${logo(t, { footer: true })}
      <p>${esc(f.tagline)}</p>
    </div>
    <nav aria-label="${esc(f.explore)}">
      <h2 class="footer-h">${esc(f.explore)}</h2>
      <ul>${PAGES.map((p) => `<li><a href="${p}.html">${esc(t.nav[NAV_KEY[p]])}</a></li>`).join('')}</ul>
    </nav>
    <nav aria-label="${esc(f.more)}">
      <h2 class="footer-h">${esc(f.more)}</h2>
      <ul>
        <li><a href="index.html#about">${esc(f.about)}</a></li>
        <li><a href="breeds.html#cat-care">${esc(f.care)}</a></li>
        <li><a href="index.html#mission">${esc(f.mission)}</a></li>
      </ul>
    </nav>
    <div>
      <h2 class="footer-h">${esc(f.contact)}</h2>
      <p class="muted-note"><span class="tag">${t.lang === 'en' ? 'Not configured' : 'غير مُعدّ'}</span> ${esc(f.contactNote)}</p>
      <h2 class="footer-h">${esc(f.language)}</h2>
      ${langSwitch(t, page)}
    </div>
  </div>
  <div class="container footer-base">
    <p>© <span data-year>${year}</span> ${esc(f.rights)}</p>
    <p>${esc(f.project)}</p>
  </div>
</footer>`;
}

export function head(t, page, { site, extraHead = '', jsonld = [] }) {
  const m = t.meta[page === 'index' ? 'home' : page];
  const url = (l) => `${site}/${l}/${page}.html`;
  const ogImg = `${site}/assets/brand/og-image.png`;
  const ld = jsonld.map((o) => `<script type="application/ld+json">${JSON.stringify(o)}</script>`).join('\n');
  const fonts = t.lang === 'ar'
    ? 'family=Tajawal:wght@400;500;700;800&family=Plus+Jakarta+Sans:wght@700;800'
    : 'family=Plus+Jakarta+Sans:wght@400;500;600;700;800';
  return `<!DOCTYPE html>
<html lang="${t.lang}" dir="${t.dir}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(m.title)}</title>
<meta name="description" content="${esc(m.desc)}">
<link rel="canonical" href="${url(t.lang)}">
<link rel="alternate" hreflang="en" href="${url('en')}">
<link rel="alternate" hreflang="ar" href="${url('ar')}">
<link rel="alternate" hreflang="x-default" href="${url('en')}">
<meta name="theme-color" content="#FFCED8">
<meta property="og:type" content="website">
<meta property="og:site_name" content="ZOOMANIA">
<meta property="og:title" content="${esc(m.title)}">
<meta property="og:description" content="${esc(m.desc)}">
<meta property="og:url" content="${url(t.lang)}">
<meta property="og:image" content="${ogImg}">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:locale" content="${t.lang === 'en' ? 'en_US' : 'ar_AE'}">
<meta property="og:locale:alternate" content="${t.lang === 'en' ? 'ar_AE' : 'en_US'}">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="../assets/brand/favicon.svg" type="image/svg+xml">
<link rel="icon" href="../assets/brand/favicon-32.png" sizes="32x32" type="image/png">
<link rel="apple-touch-icon" href="../assets/brand/apple-touch-icon.png">
<link rel="manifest" href="../site.webmanifest">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?${fonts}&display=swap">
<link rel="stylesheet" href="../assets/css/main.css">
${extraHead}
${ld}
</head>`;
}

export function page(t, pageName, body, opts) {
  return `${head(t, pageName, opts)}
<body class="page-${pageName}">
${header(t, pageName)}
<main id="main" tabindex="-1">
${body}
</main>
${footer(t, pageName)}
<script src="../assets/js/main.js" defer></script>
${(opts.scripts || []).map((s) => `<script src="../assets/js/${s}" defer></script>`).join('\n')}
</body>
</html>`;
}
