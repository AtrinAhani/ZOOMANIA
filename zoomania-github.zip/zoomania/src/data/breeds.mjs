// ZOOMANIA — breed data model (bilingual).
// Scores (0–4) are general tendencies used for filtering, comparison and the quiz.
// Individual cats vary: personality depends on genetics, socialisation, health and environment.

export const DIMENSIONS = ['sociability', 'energy', 'independence', 'affection', 'curiosity', 'routine'];

export const breeds = [
  {
    slug: 'persian',
    look: { fur: '#F6EFE8', shade: '#D9CBBE', accent: '#E9DCCF', eye: '#C98A3B', type: 'longhair', face: 'flat' },
    coat: 'long', size: 'medium', activity: 'low', grooming: 'high',
    profile: { sociability: 2, energy: 0.5, independence: 1.5, affection: 3.5, curiosity: 1, routine: 4 },
    en: {
      name: 'Persian',
      intro: 'A serene, luxurious companion with a long flowing coat and a sweet, round face. Persians often prefer calm homes and predictable days.',
      temperament: 'Often gentle, quiet and content to lounge near their people.',
      coatText: 'Long, dense double coat',
      grooming: 'Daily brushing; regular face and eye cleaning',
      activityText: 'Low — short gentle play sessions',
      sizeText: 'Medium, sturdy body (roughly 3–6 kg)',
      health: 'The flat (brachycephalic) face can be linked to breathing difficulty, eye discharge and dental crowding; heat sensitivity is higher. Polycystic kidney disease (PKD) occurs in the breed — reputable breeders DNA-test.',
      personality: 'You value calm, comfort and beautiful routines. You recharge in peaceful spaces and bring a soothing presence to the people around you.'
    },
    ar: {
      name: 'الفارسي',
      intro: 'رفيق هادئ وفاخر بفرو طويل منسدل ووجه مستدير لطيف. يميل القط الفارسي غالبًا إلى البيوت الهادئة والأيام المنتظمة.',
      temperament: 'لطيف وهادئ في الغالب، ويستمتع بالاسترخاء قرب أصحابه.',
      coatText: 'فرو طويل وكثيف بطبقتين',
      grooming: 'تمشيط يومي وتنظيف منتظم للوجه والعينين',
      activityText: 'منخفض — جلسات لعب قصيرة وهادئة',
      sizeText: 'متوسط بجسم متين (نحو 3–6 كغ)',
      health: 'قد يرتبط الوجه المسطّح بصعوبات في التنفس وإفرازات العين وتزاحم الأسنان، كما تكون حساسيته للحرارة أعلى. يظهر مرض الكلى متعدد الكيسات (PKD) في هذه السلالة، ويُجري المربّون الموثوقون فحص الحمض النووي.',
      personality: 'تقدّر الهدوء والراحة والروتين الجميل. تستعيد طاقتك في الأماكن الهادئة وتمنح من حولك حضورًا مريحًا.'
    }
  },
  {
    slug: 'ragdoll',
    look: { fur: '#F7F1EA', shade: '#B9A496', accent: '#8C7466', eye: '#4F86C6', type: 'colorpoint-long', face: 'round' },
    coat: 'long', size: 'large', activity: 'moderate', grooming: 'moderate',
    profile: { sociability: 3.5, energy: 2, independence: 1, affection: 4, curiosity: 2, routine: 2.5 },
    en: {
      name: 'Ragdoll',
      intro: 'Large, soft and famously relaxed, with striking blue eyes and a semi-long colourpoint coat. Many Ragdolls enjoy following their people from room to room.',
      temperament: 'Often affectionate, gentle and people-oriented.',
      coatText: 'Semi-long, silky coat with less undercoat',
      grooming: 'Brushing two to three times a week',
      activityText: 'Moderate — enjoys interactive play',
      sizeText: 'Large (roughly 4.5–9 kg)',
      health: 'Hypertrophic cardiomyopathy (HCM) is a recognised concern; a DNA test exists for one known mutation. Their size makes weight management important.',
      personality: 'You are warm, loyal and wonderfully easy to be around. You show love through presence, and your friends feel safe with you.'
    },
    ar: {
      name: 'الراغدول',
      intro: 'قط كبير وناعم ومشهور بهدوئه، بعينين زرقاوين لافتتين وفرو شبه طويل بنقاط لونية. يحب كثير من قطط الراغدول مرافقة أصحابها من غرفة إلى أخرى.',
      temperament: 'حنون ولطيف ومتعلّق بالناس في الغالب.',
      coatText: 'فرو حريري شبه طويل وطبقة سفلية أخف',
      grooming: 'تمشيط مرتين إلى ثلاث مرات أسبوعيًا',
      activityText: 'متوسط — يستمتع باللعب التفاعلي',
      sizeText: 'كبير (نحو 4.5–9 كغ)',
      health: 'يُعدّ اعتلال عضلة القلب الضخامي (HCM) مصدر قلق معروفًا، ويتوفر فحص جيني لإحدى الطفرات المعروفة. حجمه الكبير يجعل التحكم في الوزن مهمًا.',
      personality: 'أنت دافئ ووفيّ وسهل المعشر. تعبّر عن محبتك بحضورك، ويشعر أصدقاؤك بالأمان معك.'
    }
  },
  {
    slug: 'maine-coon',
    look: { fur: '#C79A6B', shade: '#8A5E3B', accent: '#5E3E27', eye: '#B8A13A', type: 'tabby-long', face: 'tufted' },
    coat: 'long', size: 'large', activity: 'moderate', grooming: 'moderate',
    profile: { sociability: 3, energy: 3, independence: 3, affection: 2.5, curiosity: 3.5, routine: 1.5 },
    en: {
      name: 'Maine Coon',
      intro: 'A gentle giant with tufted ears, a lion-like ruff and a plume of a tail. Maine Coons are often described as friendly, playful and dog-like.',
      temperament: 'Often sociable, good-natured and curious without being demanding.',
      coatText: 'Long, shaggy, water-resistant coat',
      grooming: 'Brushing two to three times a week, more when shedding',
      activityText: 'Moderate to active — loves climbing and puzzles',
      sizeText: 'Very large (roughly 5–11 kg)',
      health: 'HCM, hip dysplasia and spinal muscular atrophy (SMA) are known in the breed; screening is available. Large cats need sturdy climbing furniture.',
      personality: 'You are friendly, adaptable and quietly adventurous. You balance independence with real warmth — the kind of person everyone wants on a road trip.'
    },
    ar: {
      name: 'الماين كون',
      intro: 'عملاق لطيف بأذنين مزيّنتين بخصلات، وطوق فرو يشبه عُرف الأسد، وذيل كثيف كالريشة. يوصف غالبًا بأنه ودود ومرح ويشبه الكلاب في تعلّقه.',
      temperament: 'اجتماعي وطيّب الطبع وفضولي في الغالب دون أن يكون متطلبًا.',
      coatText: 'فرو طويل كثّ مقاوم للماء',
      grooming: 'تمشيط مرتين إلى ثلاث مرات أسبوعيًا، وأكثر في موسم تساقط الشعر',
      activityText: 'متوسط إلى نشيط — يحب التسلق والألغاز',
      sizeText: 'كبير جدًا (نحو 5–11 كغ)',
      health: 'من المشكلات المعروفة في السلالة: اعتلال عضلة القلب الضخامي وخلل التنسج الوركي وضمور العضلات الشوكي (SMA)، وتتوفر فحوص للكشف عنها. تحتاج القطط الكبيرة إلى أثاث تسلق متين.',
      personality: 'أنت ودود ومرن ومغامر بهدوء. توازن بين الاستقلالية والدفء الحقيقي — من النوع الذي يتمنّاه الجميع رفيقًا في الرحلات.'
    }
  },
  {
    slug: 'siamese',
    look: { fur: '#F3E6D6', shade: '#C9B29A', accent: '#4A3A33', eye: '#3F7FD1', type: 'colorpoint-short', face: 'wedge' },
    coat: 'short', size: 'medium', activity: 'high', grooming: 'low',
    profile: { sociability: 3.5, energy: 3.5, independence: 1, affection: 3, curiosity: 4, routine: 1 },
    en: {
      name: 'Siamese',
      intro: 'Elegant, slender and expressive, with sapphire eyes and a colourpoint coat. Siamese cats are known for their voices — and for having plenty to say.',
      temperament: 'Often vocal, social, intelligent and attached to their people.',
      coatText: 'Short, fine, close-lying coat',
      grooming: 'Weekly brushing',
      activityText: 'High — needs daily play and mental challenges',
      sizeText: 'Medium, slender (roughly 2.5–5.5 kg)',
      health: 'Some lines are prone to dental disease, certain eye conditions (such as progressive retinal atrophy) and respiratory issues. They may struggle when left alone for long periods.',
      personality: 'You are expressive, clever and full of conversation. You light up when connected to others and you are never boring.'
    },
    ar: {
      name: 'السيامي',
      intro: 'أنيق ونحيل ومعبّر، بعينين بلون الياقوت الأزرق وفرو بنقاط لونية. يشتهر القط السيامي بصوته — وبأن لديه دائمًا ما يقوله.',
      temperament: 'كثير المواء واجتماعي وذكي ومتعلّق بأصحابه في الغالب.',
      coatText: 'فرو قصير ناعم ملاصق للجسم',
      grooming: 'تمشيط أسبوعي',
      activityText: 'مرتفع — يحتاج إلى لعب يومي وتحديات ذهنية',
      sizeText: 'متوسط ونحيل (نحو 2.5–5.5 كغ)',
      health: 'بعض السلالات عرضة لأمراض الأسنان وبعض أمراض العيون (مثل الضمور الشبكي التدريجي) ومشكلات تنفسية. قد يعاني إذا تُرك وحيدًا لفترات طويلة.',
      personality: 'أنت معبّر وذكي ومحب للحديث. تتألق حين تكون على تواصل مع الآخرين، ولا يعرف الملل طريقًا إليك.'
    }
  },
  {
    slug: 'bengal',
    look: { fur: '#E2B270', shade: '#B27A3A', accent: '#4E3423', eye: '#7FA33A', type: 'spotted', face: 'wild' },
    coat: 'short', size: 'medium', activity: 'high', grooming: 'low',
    profile: { sociability: 2, energy: 4, independence: 3, affection: 1.5, curiosity: 4, routine: 1 },
    en: {
      name: 'Bengal',
      intro: 'Athletic and dazzling, with a glittering spotted or marbled coat that recalls a tiny leopard. Bengals are energetic explorers who love a challenge.',
      temperament: 'Often confident, highly active and endlessly curious.',
      coatText: 'Short, dense, pelt-like coat',
      grooming: 'Weekly brushing',
      activityText: 'Very high — climbing, puzzle feeders and daily play',
      sizeText: 'Medium to large, muscular (roughly 3.5–7 kg)',
      health: 'HCM and progressive retinal atrophy (PRA-b) are known; a DNA test exists for PRA-b. Without enough enrichment, boredom can lead to stress behaviours.',
      personality: 'You are bold, energetic and always learning something new. You thrive on challenges and inspire others to explore.'
    },
    ar: {
      name: 'البنغالي',
      intro: 'رياضي ومبهر، بفرو مرقّط أو مرمري لامع يذكّر بنمر صغير. القط البنغالي مستكشف نشيط يحب التحدي.',
      temperament: 'واثق وكثير النشاط وفضولي بلا حدود في الغالب.',
      coatText: 'فرو قصير كثيف يشبه الجلد الوبري',
      grooming: 'تمشيط أسبوعي',
      activityText: 'مرتفع جدًا — تسلّق وألعاب ألغاز للطعام ولعب يومي',
      sizeText: 'متوسط إلى كبير وعضلي (نحو 3.5–7 كغ)',
      health: 'من المشكلات المعروفة اعتلال عضلة القلب الضخامي والضمور الشبكي التدريجي (PRA-b)، ويتوفر فحص جيني لهذا الأخير. قد يؤدي نقص الإثراء البيئي إلى سلوكيات توتر بسبب الملل.',
      personality: 'أنت جريء ونشيط وتتعلم شيئًا جديدًا دائمًا. تزدهر بالتحديات وتلهم الآخرين للاستكشاف.'
    }
  },
  {
    slug: 'british-shorthair',
    look: { fur: '#9AA3AE', shade: '#6F7884', accent: '#58616C', eye: '#D98E2B', type: 'plush', face: 'round' },
    coat: 'short', size: 'medium', activity: 'low', grooming: 'low',
    profile: { sociability: 1.5, energy: 1.5, independence: 4, affection: 1.5, curiosity: 2, routine: 3 },
    en: {
      name: 'British Shorthair',
      intro: 'Round-faced and teddy-bear plush, often seen in classic blue-grey with copper eyes. British Shorthairs tend to be calm, dignified and easygoing.',
      temperament: 'Often calm, independent and affectionate on their own terms.',
      coatText: 'Short, very dense, plush coat',
      grooming: 'Weekly brushing, more during seasonal shedding',
      activityText: 'Low to moderate',
      sizeText: 'Medium to large, cobby (roughly 4–8 kg)',
      health: 'HCM and PKD can occur; screening helps. They can gain weight easily, so portion control and play matter.',
      personality: 'You are composed, reliable and self-assured. You enjoy your own company and offer steady, unshakable friendship.'
    },
    ar: {
      name: 'البريطاني قصير الشعر',
      intro: 'وجه مستدير وفرو كثيف كالدمية القطنية، ويُرى غالبًا باللون الرمادي المزرق الكلاسيكي مع عينين نحاسيتين. يميل إلى الهدوء والوقار وسهولة الطبع.',
      temperament: 'هادئ ومستقل وحنون بطريقته الخاصة في الغالب.',
      coatText: 'فرو قصير كثيف جدًا وناعم الملمس',
      grooming: 'تمشيط أسبوعي، وأكثر في مواسم تساقط الشعر',
      activityText: 'منخفض إلى متوسط',
      sizeText: 'متوسط إلى كبير بجسم ممتلئ (نحو 4–8 كغ)',
      health: 'قد يظهر اعتلال عضلة القلب الضخامي ومرض الكلى متعدد الكيسات، والفحص المبكر مفيد. يكتسب الوزن بسهولة، لذا يهمّ ضبط الكميات واللعب.',
      personality: 'أنت متّزن وموثوق وواثق بنفسك. تستمتع بوقتك الخاص وتقدّم صداقة ثابتة لا تتزعزع.'
    }
  },
  {
    slug: 'sphynx',
    look: { fur: '#F1C6B6', shade: '#D9988A', accent: '#C27F72', eye: '#6FA36A', type: 'hairless', face: 'wedge' },
    coat: 'hairless', size: 'medium', activity: 'high', grooming: 'high',
    profile: { sociability: 4, energy: 3, independence: 0.5, affection: 4, curiosity: 3, routine: 2.5 },
    en: {
      name: 'Sphynx',
      intro: 'Warm to the touch, wrinkly and wonderfully bold. The Sphynx is an extrovert that loves attention, cuddles and being in the middle of everything.',
      temperament: 'Often outgoing, affectionate, playful and attention-seeking.',
      coatText: 'Hairless or a fine peach-fuzz down',
      grooming: 'Regular baths and ear cleaning to manage skin oils',
      activityText: 'High — playful and acrobatic',
      sizeText: 'Medium, muscular (roughly 3–5.5 kg)',
      health: 'HCM is a recognised concern. Without fur they need protection from sun, cold and strong air conditioning, plus regular skin care.',
      personality: 'You are open-hearted, social and delightfully unconventional. You love deeply, laugh easily and are happiest surrounded by your people.'
    },
    ar: {
      name: 'السفينكس',
      intro: 'دافئ الملمس، كثير التجاعيد، وجريء بشكل رائع. السفينكس قط اجتماعي يحب الاهتمام والعناق وأن يكون في قلب كل شيء.',
      temperament: 'منفتح وحنون ومرح ويحب لفت الانتباه في الغالب.',
      coatText: 'بلا فرو أو بزغب ناعم جدًا كقشرة الخوخ',
      grooming: 'استحمام منتظم وتنظيف الأذنين للتحكم في زيوت الجلد',
      activityText: 'مرتفع — مرح وبهلواني',
      sizeText: 'متوسط وعضلي (نحو 3–5.5 كغ)',
      health: 'يُعدّ اعتلال عضلة القلب الضخامي مصدر قلق معروفًا. ولأنه بلا فرو، يحتاج إلى حماية من الشمس والبرد والتكييف القوي، مع عناية منتظمة بالجلد.',
      personality: 'أنت طيّب القلب واجتماعي ومختلف بشكل جميل. تحب بعمق وتضحك بسهولة وتكون في أسعد حالاتك بين أحبّتك.'
    }
  },
  {
    slug: 'scottish-fold',
    look: { fur: '#D7C4B0', shade: '#A68E78', accent: '#7E6857', eye: '#C9962E', type: 'fold', face: 'round' },
    coat: 'short', size: 'medium', activity: 'moderate', grooming: 'low',
    profile: { sociability: 2.5, energy: 1.5, independence: 2.5, affection: 2.5, curiosity: 2, routine: 3 },
    en: {
      name: 'Scottish Fold',
      intro: 'Known for forward-folded ears and an owl-like expression. Many are sweet and adaptable — but the gene that folds the ears also affects cartilage throughout the body.',
      temperament: 'Often gentle, adaptable and quietly affectionate.',
      coatText: 'Short or long, dense coat',
      grooming: 'Weekly brushing; check ears regularly',
      activityText: 'Moderate',
      sizeText: 'Medium (roughly 3–6 kg)',
      health: 'Important welfare note: the fold mutation causes osteochondrodysplasia — abnormal cartilage and bone development that can lead to painful, progressive joint disease in folded cats. Several veterinary and welfare bodies discourage breeding for folded ears. If you love this look, consider adopting a cat in need and ask a vet about joint care.',
      personality: 'You are gentle, thoughtful and easy to talk to. You prefer meaningful moments over noisy crowds and make people feel at home.'
    },
    ar: {
      name: 'السكوتش فولد',
      intro: 'يُعرف بأذنيه المطويتين للأمام وتعبيره الشبيه بالبومة. كثير منها لطيف وسهل التكيّف — لكن الجين المسؤول عن طيّ الأذنين يؤثر أيضًا في الغضاريف في الجسم كله.',
      temperament: 'لطيف وسهل التكيّف وحنون بهدوء في الغالب.',
      coatText: 'فرو قصير أو طويل وكثيف',
      grooming: 'تمشيط أسبوعي وفحص الأذنين بانتظام',
      activityText: 'متوسط',
      sizeText: 'متوسط (نحو 3–6 كغ)',
      health: 'ملاحظة مهمة تتعلق بالرفق بالحيوان: تسبّب طفرة طيّ الأذن خللًا في تنسّج الغضروف والعظم (Osteochondrodysplasia)، ما قد يؤدي إلى مرض مفصلي مؤلم ومتفاقم لدى القطط مطوية الأذنين. وتنصح عدة هيئات بيطرية ومعنية بالرفق بالحيوان بعدم التربية بهدف الحصول على الأذنين المطويتين. إن أعجبك هذا الشكل، ففكّر في تبنّي قط محتاج واسأل الطبيب البيطري عن العناية بالمفاصل.',
      personality: 'أنت لطيف ومتأمل وسهل الحديث. تفضّل اللحظات العميقة على الزحام الصاخب، وتجعل الناس يشعرون وكأنهم في بيتهم.'
    }
  }
];

export const filterLabels = {
  en: {
    all: 'All breeds', coat: 'Coat', activity: 'Activity', size: 'Size', grooming: 'Grooming',
    long: 'Long', short: 'Short', hairless: 'Hairless',
    low: 'Low', moderate: 'Moderate', high: 'High',
    medium: 'Medium', large: 'Large'
  },
  ar: {
    all: 'كل السلالات', coat: 'الفرو', activity: 'النشاط', size: 'الحجم', grooming: 'العناية',
    long: 'طويل', short: 'قصير', hairless: 'بلا فرو',
    low: 'منخفض', moderate: 'متوسط', high: 'مرتفع',
    medium: 'متوسط', large: 'كبير'
  }
};
