// Cat Soulmate Quiz — 10 questions × 4 answers.
// Each answer gives a 0–4 value on one or more personality dimensions.
// Scoring (see assets/js/quiz.js):
//   1. Your score on each dimension = average of the values your answers gave it (2 if never touched).
//   2. For each breed, distance = mean absolute difference across the 6 dimensions.
//   3. Match % = round(100 − distance × 25). The closest breed wins; ties keep the breed-list order.
// Deterministic: the same answers always produce the same result.

export const questions = [
  {
    en: 'Your ideal Friday evening looks like…', ar: 'أمسية الجمعة المثالية بالنسبة لك هي…',
    answers: [
      { en: 'A lively dinner with a big group of friends', ar: 'عشاء مفعم بالحيوية مع مجموعة كبيرة من الأصدقاء', v: { sociability: 4, energy: 3 } },
      { en: 'A cosy film night at home with someone close', ar: 'سهرة أفلام دافئة في البيت مع شخص مقرّب', v: { affection: 4, sociability: 2, energy: 1 } },
      { en: 'Trying a new workshop, gallery or pop-up', ar: 'تجربة ورشة جديدة أو معرض أو فعالية مؤقتة', v: { curiosity: 4, energy: 3 } },
      { en: 'Quiet time alone with a good book', ar: 'وقت هادئ بمفردك مع كتاب جيد', v: { independence: 4, sociability: 1, energy: 0.5 } }
    ]
  },
  {
    en: 'How would you describe your mornings?', ar: 'كيف تصف صباحاتك؟',
    answers: [
      { en: 'Same steps, same time, every day', ar: 'الخطوات نفسها وفي الوقت نفسه كل يوم', v: { routine: 4 } },
      { en: 'Mostly steady, with small changes', ar: 'ثابتة غالبًا مع تغييرات بسيطة', v: { routine: 3 } },
      { en: 'It depends on the day', ar: 'تعتمد على طبيعة اليوم', v: { routine: 1.5 } },
      { en: 'Routine? Every morning is an adventure', ar: 'روتين؟ كل صباح مغامرة جديدة', v: { routine: 0, curiosity: 3 } }
    ]
  },
  {
    en: 'A friend is having a hard day. You…', ar: 'صديقك يمرّ بيوم صعب. ماذا تفعل؟',
    answers: [
      { en: 'Go over straight away with snacks and a hug', ar: 'تذهب إليه فورًا مع وجبات خفيفة وعناق', v: { affection: 4, sociability: 3 } },
      { en: 'Call and listen carefully for as long as needed', ar: 'تتصل به وتستمع إليه باهتمام طوال الوقت الذي يحتاجه', v: { affection: 3, independence: 2 } },
      { en: 'Send practical ideas to help fix the problem', ar: 'ترسل له أفكارًا عملية لحل المشكلة', v: { independence: 3, curiosity: 2 } },
      { en: 'Give them space until they reach out', ar: 'تمنحه مساحته حتى يتواصل هو معك', v: { independence: 4, affection: 1.5 } }
    ]
  },
  {
    en: 'Pick your perfect weekend in the UAE:', ar: 'اختر عطلة نهاية الأسبوع المثالية في الإمارات:',
    answers: [
      { en: 'Hiking and kayaking in Hatta', ar: 'المشي الجبلي والتجديف في حتّا', v: { energy: 4, curiosity: 3 } },
      { en: 'A sunset beach walk and a café', ar: 'نزهة على الشاطئ وقت الغروب ثم مقهى', v: { energy: 2, sociability: 3 } },
      { en: 'A home project — coding, building or crafting', ar: 'مشروع في البيت — برمجة أو تركيب أو صناعة يدوية', v: { curiosity: 3, independence: 3, energy: 1.5 } },
      { en: 'Spa, slow brunch and a long nap', ar: 'سبا وفطور متأخر على مهل وقيلولة طويلة', v: { energy: 0, routine: 3 } }
    ]
  },
  {
    en: 'In a group project, you are usually…', ar: 'في المشاريع الجماعية، أنت عادةً…',
    answers: [
      { en: 'The presenter who brings the energy', ar: 'المقدّم الذي يبثّ الحماس', v: { sociability: 4, energy: 3 } },
      { en: 'The organiser with the timeline', ar: 'المنظّم صاحب الجدول الزمني', v: { routine: 4, independence: 2 } },
      { en: 'The researcher exploring new ideas', ar: 'الباحث الذي يستكشف الأفكار الجديدة', v: { curiosity: 4, independence: 3 } },
      { en: 'The supportive teammate who keeps everyone happy', ar: 'الزميل الداعم الذي يُسعد الجميع', v: { affection: 3.5, sociability: 2.5 } }
    ]
  },
  {
    en: 'Your messaging style is…', ar: 'أسلوبك في الرسائل هو…',
    answers: [
      { en: 'Instant replies and long voice notes', ar: 'ردود فورية ورسائل صوتية طويلة', v: { sociability: 4, affection: 3 } },
      { en: 'Thoughtful replies within a few hours', ar: 'ردود مدروسة خلال بضع ساعات', v: { sociability: 2.5, routine: 3 } },
      { en: 'I reply when I am in the mood', ar: 'أردّ حين أكون في المزاج المناسب', v: { independence: 4 } },
      { en: 'Memes and links all day long', ar: 'صور مضحكة وروابط طوال اليوم', v: { energy: 3.5, sociability: 3, curiosity: 2.5 } }
    ]
  },
  {
    en: 'Your favourite workspace is…', ar: 'مساحة العمل المفضلة لديك هي…',
    answers: [
      { en: 'Neat, minimal and perfectly organised', ar: 'مرتّبة وبسيطة ومنظمة تمامًا', v: { routine: 4, energy: 1 } },
      { en: 'Cosy, with blankets, candles and plants', ar: 'دافئة، فيها بطانيات وشموع ونباتات', v: { affection: 3.5, energy: 1 } },
      { en: 'Full of gadgets and half-finished projects', ar: 'مليئة بالأجهزة والمشاريع غير المكتملة', v: { curiosity: 4, energy: 3 } },
      { en: 'Anywhere — a café, the sofa, the floor', ar: 'أي مكان — مقهى أو أريكة أو حتى الأرض', v: { independence: 3, routine: 1 } }
    ]
  },
  {
    en: 'When you learn a new skill, you…', ar: 'عندما تتعلم مهارة جديدة، فإنك…',
    answers: [
      { en: 'Jump in and experiment immediately', ar: 'تبدأ فورًا وتجرّب بنفسك', v: { curiosity: 4, energy: 4, routine: 0.5 } },
      { en: 'Follow a structured course step by step', ar: 'تتّبع دورة منظمة خطوة بخطوة', v: { routine: 3.5, curiosity: 2.5 } },
      { en: 'Learn together with a friend', ar: 'تتعلّمها مع صديق', v: { sociability: 3.5, affection: 3 } },
      { en: 'Teach yourself slowly, at your own pace', ar: 'تعلّم نفسك بهدوء وعلى طريقتك', v: { independence: 4, energy: 1 } }
    ]
  },
  {
    en: 'Your dream home is…', ar: 'بيت أحلامك هو…',
    answers: [
      { en: 'Always full of guests and good food', ar: 'مليء دائمًا بالضيوف والطعام اللذيذ', v: { sociability: 4, energy: 3 } },
      { en: 'A calm apartment with soft light', ar: 'شقة هادئة بإضاءة ناعمة', v: { energy: 0.5, routine: 3.5, affection: 3 } },
      { en: 'A loft with high shelves and city views', ar: 'شقة علوية برفوف عالية وإطلالة على المدينة', v: { energy: 3.5, curiosity: 3.5 } },
      { en: 'A private retreat where I can recharge', ar: 'ملاذ خاص أستعيد فيه طاقتي', v: { independence: 4, sociability: 1 } }
    ]
  },
  {
    en: 'Your friends would describe you as…', ar: 'يصفك أصدقاؤك بأنك…',
    answers: [
      { en: 'The life of the party', ar: 'روح الجلسة', v: { sociability: 4, energy: 4 } },
      { en: 'The warm heart of the group', ar: 'القلب الدافئ للمجموعة', v: { affection: 4 } },
      { en: 'The curious explorer', ar: 'المستكشف الفضولي', v: { curiosity: 4, energy: 3 } },
      { en: 'The calm, independent one', ar: 'الهادئ المستقل', v: { independence: 4, routine: 3, energy: 1 } }
    ]
  }
];

export const dimensionLabels = {
  en: { sociability: 'Sociability', energy: 'Energy', independence: 'Independence', affection: 'Affection', curiosity: 'Curiosity', routine: 'Love of routine' },
  ar: { sociability: 'الاجتماعية', energy: 'الطاقة', independence: 'الاستقلالية', affection: 'الحنان', curiosity: 'الفضول', routine: 'حب الروتين' }
};
