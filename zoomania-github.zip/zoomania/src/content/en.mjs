export default {
  lang: 'en', dir: 'ltr', other: 'ar', switchLabel: 'العربية', switchAria: 'عرض هذه الصفحة بالعربية',
  skip: 'Skip to main content',
  nav: { home: 'Home', breeds: 'Cat Breeds', quiz: 'Cat Soulmate Quiz', dubai: 'Cats in Dubai', menu: 'Menu', close: 'Close menu', primary: 'Primary' },
  meta: {
    home: { title: 'ZOOMANIA — Discover the Wonderful World of Cats', desc: 'Explore cat breeds, responsible cat care, a cat personality quiz and caring for cats in Dubai — a warm, bilingual guide to the world of cats.' },
    breeds: { title: 'Cat Breeds & Cat Care Guide | ZOOMANIA', desc: 'Compare eight popular cat breeds — temperament, coat, grooming, size and health — plus a complete, vet-referenced cat care guide.' },
    quiz: { title: 'Cat Soulmate Quiz — Which Cat Breed Matches Your Personality? | ZOOMANIA', desc: 'Take the free 10-question Cat Soulmate Quiz and discover which cat breed matches your personality. No sign-up needed.' },
    dubai: { title: 'Cats in Dubai — Cat Care, Adoption & Pet Rules | ZOOMANIA', desc: 'Cat care in Dubai: hot-weather tips, indoor living, adopting a cat in Dubai, animal welfare initiatives and official registration resources.' }
  },
  footer: {
    tagline: 'A warm, bilingual guide to cats — made with curiosity and care.',
    explore: 'Explore', more: 'More', about: 'About Atrin', care: 'Cat Care', mission: 'Our Mission',
    contact: 'Contact', contactNote: 'Contact details are not configured yet.',
    project: 'An educational university project by Atrin.',
    rights: 'ZOOMANIA. All rights reserved.', language: 'Language'
  },
  home: {
    eyebrow: 'Cats · Care · Character',
    h1: 'Discover the Wonderful World of Cats.',
    tagline: 'Every Cat Has a Personality. So Do You.',
    lead: 'ZOOMANIA is a calm corner of the internet for cat lovers — explore breeds, learn thoughtful care, and find the feline personality that feels like yours.',
    cta1: 'Find Your Cat Soulmate', cta2: 'Explore Cat Breeds',
    heroAlt: 'Three illustrated cats — a cream long-haired cat, a blue-grey shorthair and a ginger tabby — sitting together.',
    stats: [['8', 'breeds explored'], ['10', 'quiz questions'], ['2', 'languages']],
    welcome: {
      kicker: 'Welcome to ZOOMANIA', h2: 'A softer, smarter way to learn about cats',
      p: 'Cats are curious, complex and wonderfully individual. ZOOMANIA brings together clear breed profiles, practical care guidance and a playful personality quiz — designed for adults and young adults, in English and Arabic.',
      cards: [
        ['Learn', 'Breed profiles that are honest about temperament tendencies and inherited health issues.'],
        ['Care', 'Everyday care essentials, from hydration to senior years, with trusted veterinary references.'],
        ['Play', 'One delightful quiz that matches your personality with a cat breed — just for fun.']
      ]
    },
    featured: { kicker: 'Featured breeds', h2: 'Meet a few favourites', p: 'A taste of the eight breeds on our breeds page.', all: 'See all eight breeds', view: 'View profile' },
    quizPromo: { kicker: 'The Cat Soulmate Quiz', h2: 'Which cat matches your personality?', p: 'Ten quick questions about your evenings, your friendships and your favourite workspace. We map your answers across six playful dimensions and introduce you to your feline match.', cta: 'Start the quiz', note: '≈ 3 minutes · No sign-up · For entertainment' },
    care: { kicker: 'Cat care essentials', h2: 'Small habits, happy cats', p: 'Good care is mostly about consistency. Here are the foundations — the full guide lives on our breeds page.', cta: 'Read the full care guide',
      items: [['Fresh water, always', 'Several bowls or a fountain help cats drink more.'], ['Balanced nutrition', 'A complete diet suited to age and health.'], ['Daily play', 'Short play sessions keep body and mind active.'], ['Yearly vet visits', 'Prevention catches problems early.']] },
    dubai: { kicker: 'Cats in Dubai', h2: 'Caring for cats in a city of sunshine', p: 'Dubai life brings its own questions: high-rise balconies, summer heat and registration rules. Our Dubai guide covers responsible ownership, adoption and verified local resources.', cta: 'Explore cats in Dubai', chips: ['Hot-weather care', 'Adoption', 'Registration', 'Animal welfare'] },
    about: {
      kicker: 'Meet Atrin', h2: 'The person behind ZOOMANIA',
      intro: 'Hi, I’m Atrin!',
      paras: [
        'I’m currently a Foundation Year student at Heriot-Watt University, studying toward Engineering Computer Science. ZOOMANIA is my very first website project.',
        'I’ve always been drawn to computers and the creative possibilities of technology, and I also love cats. This website is where those interests meet: a welcoming place to discover different cat breeds, explore a fun personality quiz, and learn about thoughtful, responsible cat care.'
      ],
      quote: 'As I learn more about building websites, I hope to keep improving ZOOMANIA — one idea, one design, and one line of code at a time.',
      sign: '— Atrin, founder of ZOOMANIA',
      portrait: 'Atrin — founder of ZOOMANIA', portraitAlt: 'Portrait of Atrin, founder of ZOOMANIA', badge: 'Founder', badge2: 'CS student',
      factsTitle: 'Quick facts',
      facts: [
        ['study', 'Studying', 'Foundation Year, Heriot-Watt University'],
        ['path', 'Pathway', 'Engineering Computer Science'],
        ['code', 'This project', 'ZOOMANIA — my very first website'],
        ['heart', 'Loves', 'Computers, technology and cats']
      ],
      whyTitle: 'What you’ll find here',
      why: [
        ['Discover breeds', 'Honest, side-by-side profiles of eight popular cat breeds.', 'breeds.html'],
        ['Play the quiz', 'A fun personality quiz that matches you with a feline soulmate.', 'quiz.html'],
        ['Care thoughtfully', 'Practical, responsible cat care — including life with cats in Dubai.', 'breeds.html#cat-care']
      ],
      journeyTitle: 'The journey so far',
      journey: [
        ['The spark', 'A lifelong pull towards computers, technology — and cats.'],
        ['Learning to build', 'Starting the Foundation Year at Heriot-Watt, on the way to Engineering Computer Science.'],
        ['ZOOMANIA', 'Bringing both passions together in a first real website, in English and Arabic.'],
        ['What’s next', 'Growing ZOOMANIA one idea, one design and one line of code at a time.']
      ]
    },
    mission: {
      h3: 'Our Mission',
      items: [
        ['Cat education', 'Share clear, balanced information about breeds and behaviour — without myths or one-size-fits-all promises.'],
        ['Responsible care', 'Encourage adoption, prevention and kind, informed ownership, especially for cats living in Dubai.'],
        ['Meaningful digital experiences', 'Prove that a website can be beautiful, accessible and genuinely helpful at the same time.']
      ]
    }
  },
  breedsPage: {
    kicker: 'Cat breeds', h1: 'Explore Cat Breeds',
    lead: 'Eight popular breeds, described honestly. Remember: breed shapes tendencies, but every cat is an individual — personality also depends on socialisation, health and environment.',
    filterTitle: 'Filter breeds', results: 'breeds shown', reset: 'Reset filters',
    fields: { temperament: 'Temperament', coat: 'Coat', grooming: 'Grooming', activity: 'Activity', size: 'Size', health: 'Health considerations' },
    compareBtn: 'Compare', compareH2: 'Compare two breeds', compareP: 'Choose any two breeds to see them side by side.', compareA: 'First breed', compareB: 'Second breed', compareCaption: 'Side-by-side comparison of two cat breeds',
    photoNote: 'Illustration — real breed photo can be added in /assets/photos/',
    traits: 'Tendency scores (0–4)'
  },
  care: {
    kicker: 'Cat Care Guide', h2: 'Everything a cat needs to thrive',
    lead: 'A practical, evidence-informed overview. It is not a substitute for advice from your veterinarian, who knows your cat.',
    topics: [
      ['nutrition', 'Nutrition', 'Cats are obligate carnivores: they need nutrients found in animal tissue, such as taurine. Choose a complete and balanced food labelled for your cat’s life stage. Measure portions, avoid frequent treats, and never offer onions, garlic, chocolate, grapes, alcohol or lilies (lilies are highly toxic to cats).'],
      ['hydration', 'Hydration', 'Many cats drink little by nature. Offer fresh water in several wide bowls away from the food and litter, consider a fountain, and include wet food if your vet agrees. Hydration matters even more in hot climates.'],
      ['grooming', 'Grooming', 'Brush according to coat type — daily for long coats, weekly for most short coats. Check claws, ears, eyes and teeth during calm grooming sessions. Hairless cats need gentle bathing to manage skin oils.'],
      ['litter', 'Litter box hygiene', 'A common guideline is one box per cat plus one, in quiet, easy-to-reach places. Scoop daily and wash boxes regularly with mild, unscented products. Sudden changes in litter habits can signal a medical problem.'],
      ['enrichment', 'Indoor exercise & enrichment', 'Indoor cats need to hunt, climb, scratch and explore. Offer wand-toy play sessions, vertical spaces, scratching posts, food puzzles and safe window views. Rotate toys to keep them interesting.'],
      ['checkups', 'Veterinary checkups', 'Healthy adult cats generally benefit from at least one wellness exam a year; kittens and senior cats often need more frequent visits. Cats hide pain well, so routine exams catch problems early.'],
      ['vaccination', 'Vaccination', 'Core vaccines usually protect against feline panleukopenia, herpesvirus and calicivirus, and rabies where required by law — as in Dubai. Your vet will tailor any additional vaccines to your cat’s lifestyle.'],
      ['neutering', 'Neutering', 'Spaying and neutering prevent unplanned litters, reduce roaming and some behaviour problems, and support efforts to manage stray populations. Ask your vet about the right timing.'],
      ['warning', 'Common warning signs', 'Contact a vet promptly for changes in appetite, weight, thirst or litter habits; vomiting or diarrhoea that persists; hiding; or limping. Seek emergency care for breathing difficulty, straining in the litter box without passing urine, collapse or suspected poisoning.'],
      ['senior', 'Senior cat care', 'From around age 11, cats are often considered senior. Provide soft, warm beds, low-entry litter boxes and steps to favourite places, and ask about more frequent checkups including blood and blood-pressure tests.'],
      ['safety', 'Safe indoor environments', 'Fit secure screens on windows and balconies, tidy away cords, string and small objects, store medicines and cleaning products safely, and check that houseplants are non-toxic before bringing them home.']
    ],
    faqH3: 'Cat care FAQ',
    faq: [
      ['How much should my cat eat?', 'It depends on age, weight, activity and the food’s energy content. Start with the label’s guidance, weigh your cat regularly and ask your vet to help you set a target.'],
      ['Is milk good for cats?', 'Most adult cats are lactose intolerant, so cow’s milk can cause stomach upset. Fresh water is the best drink.'],
      ['Do indoor cats need vaccines?', 'Yes. Viruses can enter on shoes and clothing, and cats may escape or need boarding. In Dubai, rabies vaccination is also part of the legal registration process.'],
      ['How do I know if my cat is in pain?', 'Look for hiding, reduced grooming, a hunched posture, squinting, reluctance to jump or changes in appetite. If in doubt, contact your vet.']
    ],
    refsH3: 'Trusted references',
    refs: [
      ['International Cat Care', 'https://icatcare.org/'],
      ['Cat Friendly (American Association of Feline Practitioners)', 'https://catfriendly.com/'],
      ['WSAVA Vaccination Guidelines', 'https://wsava.org/global-guidelines/vaccination-guidelines/'],
      ['Cornell Feline Health Center', 'https://www.vet.cornell.edu/departments-centers-and-institutes/cornell-feline-health-center'],
      ['ASPCA — Toxic and non-toxic plants', 'https://www.aspca.org/pet-care/animal-poison-control/toxic-and-non-toxic-plants']
    ],
    disclaimer: 'Educational information only — always consult a licensed veterinarian about your own cat.'
  },
  quiz: {
    kicker: 'The Cat Soulmate Quiz', h1: 'Which Cat Breed Matches Your Personality?',
    lead: 'Ten questions, four answers each. There are no wrong answers — just pick what feels most like you.',
    start: 'Start the quiz', how: 'How it works',
    howText: 'Each answer adds points to six playful dimensions: sociability, energy, independence, affection, curiosity and love of routine. We compare your profile with each breed’s typical tendencies and show the closest match.',
    question: 'Question', of: 'of', prev: 'Previous', next: 'Next', finish: 'See my result', choose: 'Choose one answer',
    keyboardHint: 'Tip: use arrow keys to move between answers and Enter to continue.',
    resultKicker: 'Your Cat Soulmate is', match: 'Entertainment match',
    matchNote: 'This percentage is for entertainment only — it is not a scientifically validated psychological measure, and real cats are individuals.',
    traitsH3: 'What you have in common', explainH3: 'How we reached this result',
    explain: 'Your score on each dimension is the average of the points your answers gave it, gently stretched to make your leanings clearer. We then measure the average difference between your profile and each breed’s typical profile. The closest breed wins. Match % = 100 − (average difference × 25).',
    you: 'You', breed: 'Breed',
    runnersUp: 'Also a good match',
    explore: 'Explore this breed', restart: 'Take the quiz again', download: 'Download result card', share: 'Share result', copy: 'Copy result',
    shared: 'Result copied to your clipboard.', downloaded: 'Your result card is downloading.', downloadFail: 'Downloads are blocked here — use “Copy result” instead.',
    shareText: (b, p) => `My Cat Soulmate is the ${b} (${p}% entertainment match) on ZOOMANIA!`,
    cardTitle: 'My Cat Soulmate', welfare: 'Thinking of welcoming a cat? Consider adoption — see our Cats in Dubai guide.',
    photoAlt: (b) => `Illustration of a ${b} cat`
  },
  dubai: {
    kicker: 'Cats in Dubai', h1: 'Cat Care in Dubai',
    lead: 'From high-rise apartments to summer heat, caring for a cat in Dubai has its own rhythm. Here is a calm, practical guide to responsible cat ownership in the UAE.',
    toc: 'On this page', updated: 'Information last checked: November 2026.',
    s1: { h2: 'Cats and Dubai lifestyle', p: [
      'Dubai is home to a large, diverse community of cat lovers — and to many apartment-dwelling cats. Indoor living can be safe, enriching and happy when the space is designed with a cat’s instincts in mind.',
      'Choose a cat whose energy suits your home and schedule, plan for care while you travel, and check your building’s or landlord’s pet policy before you adopt.'
    ], cards: [['Apartment-ready', 'Vertical spaces, window perches and daily play turn a small flat into a full territory.'], ['Balcony safety', 'Cats can fall from height. Secure balconies and windows with sturdy netting or screens.'], ['Travel plans', 'Arrange a trusted sitter or a licensed boarding facility well before holidays.']] },
    s2: { h2: 'Caring for cats in hot weather', p: 'UAE summers can be extreme. Indoor cats are safest, but heat still matters inside the home.',
      tips: [
        ['Keep it cool', 'Keep living spaces comfortably cool and shaded, and give cats cool spots such as tiled floors. Plan for power or AC failures.'],
        ['Water everywhere', 'Place several water bowls around the home and refresh them often; wet food adds moisture.'],
        ['No hot cars — ever', 'A parked car heats up dangerously within minutes, even with windows open.'],
        ['Hot surfaces', 'Balcony tiles and outdoor paving can burn paws in summer.'],
        ['Know heatstroke signs', 'Panting, drooling, restlessness, weakness or bright red gums need urgent veterinary care. Flat-faced breeds such as Persians are at higher risk.'],
        ['Sun protection', 'Hairless and white-eared cats can burn; limit direct sun through windows.']
      ] },
    s3: { h2: 'Adoption and responsible ownership', p: [
      'Adopting gives a cat a second chance and helps reduce the number of stray and abandoned animals. Before you adopt, make sure you can commit for the cat’s whole life — often 15 years or more.'
    ], checklistH3: 'Before you bring a cat home',
      checklist: ['Confirm your housing allows pets', 'Budget for food, litter, vet care and emergencies', 'Prepare a quiet room, litter box, scratching post and hiding place', 'Book a vet visit for a health check, vaccination and microchip registration', 'Plan for travel, moves and long-term care'] },
    s4: { h2: 'Dubai animal welfare', p: 'Dubai Municipality runs several programmes that support animal welfare and responsible ownership. The highlights below are summarised from official announcements.',
      items: [
        ['Animal Welfare Shelter, Warsan', 'In July 2026 Dubai Municipality opened an integrated pet shelter at the Birds and Pets Market in Warsan, alongside a digital adoption platform where residents can browse animals and review their health and behaviour profiles.', 'https://www.dm.gov.ae/integrated-pet-shelter-opens-and-digital-adoption-launched/', 'Dubai Municipality announcement'],
        ['Trap-Neuter-Return (TNR)', 'The municipality applies Trap-Neuter-Return — and, where appropriate, Trap-Neuter-Vaccinate-Return — to manage community cat populations humanely.', 'https://www.dm.gov.ae/integrated-pet-shelter-opens-and-digital-adoption-launched/', 'Dubai Municipality'],
        ['Ehsan feeding stations', 'In 2026 Dubai Municipality launched “Ehsan Stations”, AI-powered smart devices that feed stray animals in an organised, sustainable way.', 'https://dm.gov.ae/dubai-municipality-launches-ehsan-stations-initiative-to-feed-stray-animals', 'Dubai Municipality announcement'],
        ['Veterinary services', 'The municipality’s Veterinary Services Section provides vaccination, registration and adoption services and oversees veterinary standards in the emirate.', 'https://www.dm.gov.ae/municipality-business/veterinary-services/', 'Veterinary Services Section']
      ] },
    s5: { h2: 'Rules and resources', p: 'A short overview of what pet owners commonly need. Requirements and fees can change, so always confirm details with Dubai Municipality or a licensed veterinary clinic.',
      rules: [
        ['Microchip', 'Pet cats and dogs in Dubai need an ISO-compliant microchip linked to the owner’s details in Dubai Municipality’s veterinary records.'],
        ['Rabies vaccination', 'An up-to-date rabies vaccination record is required for registration.'],
        ['Registration', 'Cats and dogs must be registered with Dubai Municipality. Registration can be completed through licensed veterinary clinics or the municipality’s online services, and is typically renewed alongside the yearly rabies vaccination.'],
        ['Keep details current', 'If you move or change your phone number, update your pet’s registration so a found pet can be returned to you.'],
        ['Animal welfare law', 'UAE Federal Law No. 16 of 2007 on animal welfare (as amended) protects animals from abuse and neglect, and abandoning a pet is prohibited.']
      ],
      linksH3: 'Official links',
      links: [
        ['Dubai Municipality — official website (services, registration, adoption)', 'https://www.dm.gov.ae/'],
        ['Dubai Municipality — Veterinary Services Section', 'https://www.dm.gov.ae/municipality-business/veterinary-services/'],
        ['Ministry of Climate Change and Environment (MOCCAE)', 'https://www.moccae.gov.ae/'],
        ['UAE Legislation portal (federal laws)', 'https://uaelegislation.gov.ae/']
      ],
      phone: 'Dubai Municipality call centre: 800 900',
      disclaimer: 'This page is educational and is not legal advice.' },
    s6: { h2: 'Dubai cat care FAQ', faq: [
      ['Do I need to register my cat in Dubai?', 'Yes. Dubai Municipality requires pet cats and dogs to be microchipped, vaccinated against rabies and registered. A licensed vet clinic can guide you through the process.'],
      ['Where can I adopt a cat in Dubai?', 'Dubai Municipality offers adoption through its website and the DubaiNow app, and its Warsan shelter cares for cats awaiting homes. Licensed local rescue groups also rehome cats.'],
      ['Can my cat live happily indoors in an apartment?', 'Yes — with daily play, climbing spaces, scratching posts, window views and secure balconies, indoor cats can live full, healthy lives.'],
      ['How do I keep my cat safe in summer?', 'Keep your home cool, offer plenty of water, never leave a cat in a car and learn the signs of heatstroke. Contact a vet immediately if you are worried.'],
      ['What should I do if I find a stray or injured cat?', 'Keep a safe distance if the cat seems frightened, and contact Dubai Municipality (800 900) or a veterinary clinic for advice. A vet can scan for a microchip to find the owner.'],
      ['Should I neuter my cat?', 'For most pet cats, yes. Neutering prevents unplanned litters and supports Dubai’s efforts to reduce stray populations. Ask your vet about timing.']
    ] },
    more: 'More Dubai guides will be added here as ZOOMANIA grows.'
  }
};
