// End-to-end checks in headless Chrome: console errors, overflow, a11y (axe), nav, anchors, quiz.
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PORT = 4179, BASE = `http://localhost:${PORT}`;
const shots = path.join(ROOT, 'test-results'); fs.mkdirSync(shots, { recursive: true });
const srv = spawn('node', ['scripts/serve.mjs'], { cwd: ROOT, env: { ...process.env, PORT: String(PORT) } });
await new Promise((r) => setTimeout(r, 700));
// Uses CHROME_PATH, a system Chrome if found, or Playwright's own Chromium (npx playwright install chromium).
const exe = process.env.CHROME_PATH || ['/usr/bin/google-chrome', '/usr/bin/chromium', 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'].find((p) => fs.existsSync(p));
const browser = await chromium.launch({ ...(exe ? { executablePath: exe } : {}), args: ['--no-sandbox'] });
const axe = fs.readFileSync(path.join(ROOT, 'node_modules/axe-core/axe.min.js'), 'utf8');
let fails = 0; const ok = (c, m) => { console.log(`${c ? '✓' : '✗'} ${m}`); if (!c) fails++; };
const pages = ['index', 'breeds', 'quiz', 'dubai'];

for (const [vpName, vp] of [['desktop', { width: 1366, height: 900 }], ['tablet', { width: 820, height: 1180 }], ['mobile', { width: 390, height: 844 }]]) {
  const ctx = await browser.newContext({ viewport: vp, reducedMotion: 'reduce' });
  for (const lang of ['en', 'ar']) for (const p of pages) {
    const page = await ctx.newPage(); const errs = [];
    page.on('console', (m) => { const u = m.location()?.url || ''; if (m.type() === 'error' && !(u && !u.startsWith(BASE))) errs.push(m.text() + ' @ ' + u); });
    page.on('pageerror', (e) => errs.push(String(e)));
    page.on('requestfailed', (r) => { if (r.url().startsWith(BASE)) errs.push('404 ' + r.url()); });
    const res = await page.goto(`${BASE}/${lang}/${p}.html`, { waitUntil: 'load' });
    ok(res.status() === 200, `${vpName} ${lang}/${p} loads`);
    const meta = await page.evaluate(() => ({ lang: document.documentElement.lang, dir: document.documentElement.dir, overflow: document.documentElement.scrollWidth - innerWidth, h1: document.querySelectorAll('h1').length, sw: document.querySelector('.lang-switch').getAttribute('href') }));
    ok(meta.lang === lang && meta.dir === (lang === 'ar' ? 'rtl' : 'ltr'), `${lang}/${p} lang/dir = ${meta.lang}/${meta.dir}`);
    ok(meta.overflow <= 0, `${vpName} ${lang}/${p} no horizontal overflow (${meta.overflow}px)`);
    ok(meta.h1 === 1, `${lang}/${p} exactly one h1`);
    ok(meta.sw === `../${lang === 'en' ? 'ar' : 'en'}/${p}.html`, `${lang}/${p} language switch → ${meta.sw}`);
    if (vpName === 'desktop' || p === 'index') {
      await page.addScriptTag({ content: axe });
      const r = await page.evaluate(async () => (await axe.run(document, { runOnly: ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa'] })).violations.map((v) => `${v.id} (${v.nodes.length}): ${v.nodes[0].target} — ${v.nodes[0].failureSummary?.split('\n')[1] || ''}`));
      ok(r.length === 0, `${vpName} ${lang}/${p} axe WCAG 2.2 AA: ${r.length ? r.join(' | ') : 'no violations'}`);
    }
    await page.screenshot({ path: `${shots}/${vpName}-${lang}-${p}.png`, fullPage: p !== 'quiz' ? false : false });
    ok(errs.length === 0, `${vpName} ${lang}/${p} no console errors ${errs.join(' | ')}`);
    await page.close();
  }
  await ctx.close();
}

// Functional flows (desktop, motion allowed)
const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
for (const lang of ['en', 'ar']) {
  const page = await ctx.newPage(); const errs = []; page.on('pageerror', (e) => errs.push(String(e)));
  await page.goto(`${BASE}/${lang}/quiz.html`);
  await page.click('[data-quiz-start]');
  for (let q = 0; q < 10; q++) {
    await page.keyboard.press('Tab'); // focus moves from legend into radio group
    const pick = q % 4;
    await page.locator('.answer').nth(pick).click();
    await page.click('[data-next]');
  }
  const name = await page.textContent('[data-result-name]');
  const pct = await page.textContent('[data-result-pct]');
  const visible = await page.isVisible('[data-quiz-result]');
  ok(visible && name.trim().length > 0, `${lang} quiz completes → ${name} ${pct}`);
  ok((await page.locator('[data-result-media] svg, [data-result-media] img').count()) === 1, `${lang} quiz result shows breed visual`);
  ok((await page.locator('[data-result-table] tr').count()) === 6, `${lang} quiz explanation table has 6 dimensions`);
  const href = await page.getAttribute('[data-result-explore]', 'href');
  ok(/^breeds\.html#breed-/.test(href), `${lang} explore link → ${href}`);
  const dl = page.waitForEvent('download', { timeout: 5000 }).catch(() => null);
  await page.click('[data-download]');
  const d = await dl; ok(!!d, `${lang} result card download (${d ? d.suggestedFilename() : 'none'})`);
  await page.click('[data-restart]');
  ok(await page.isVisible('[data-quiz-panel]'), `${lang} restart returns to question 1`);
  // keyboard-only run
  await page.goto(`${BASE}/${lang}/quiz.html`);
  await page.focus('[data-quiz-start]'); await page.keyboard.press('Enter');
  for (let q = 0; q < 10; q++) { await page.focus(`.answer input >> nth=0`); await page.keyboard.press('ArrowDown'); await page.keyboard.press('Enter'); }
  ok(await page.isVisible('[data-quiz-result]'), `${lang} quiz completes with keyboard only`);
  ok(errs.length === 0, `${lang} quiz no JS errors ${errs.join('|')}`);
  await page.waitForTimeout(1000); await page.screenshot({ path: `${shots}/flow-${lang}-quiz-result.png`, fullPage: true });

  // Breeds: filter + compare
  await page.goto(`${BASE}/${lang}/breeds.html`);
  await page.locator('input[name="coat"][value="hairless"]').check({ force: true });
  ok((await page.textContent('[data-count]')) === '1', `${lang} filter hairless → 1 breed`);
  await page.locator('button[type="reset"]').click(); await page.waitForTimeout(50);
  ok((await page.textContent('[data-count]')) === '8', `${lang} reset → 8 breeds`);
  await page.selectOption('[data-compare-b]', 'sphynx');
  ok((await page.textContent('[data-col="b"]')).trim() === (lang === 'en' ? 'Sphynx' : 'السفينكس'), `${lang} compare updates column`);
  // Anchors
  for (const [from, sel] of [['index.html#about', '#about'], ['index.html#mission', '#mission'], ['breeds.html#cat-care', '#cat-care']]) {
    await page.goto(`${BASE}/${lang}/${from}`); await page.waitForTimeout(2200);
    const top = await page.evaluate((s) => document.querySelector(s).getBoundingClientRect().top, sel);
    ok(Math.abs(top) < 200, `${lang} anchor ${from} scrolls to section (top=${Math.round(top)})`);
  }
  // Mobile menu
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${BASE}/${lang}/index.html`);
  await page.click('.nav-toggle');
  ok(await page.isVisible('#nav-list a[href="dubai.html"]'), `${lang} mobile menu opens`);
  await page.screenshot({ path: `${shots}/mobile-${lang}-menu.png` });
  await page.close();
}
// Root redirect
const rp = await ctx.newPage(); await rp.goto(`${BASE}/`); await rp.waitForURL(/en\/index\.html/);
ok(rp.url().endsWith('/en/index.html'), `root redirects → ${rp.url()}`);

// GitHub Pages project sub-path (https://<user>.github.io/<repo>/): every page and asset must resolve
const PORT2 = 4189, SUB = '/zoomania';
const srv2 = spawn('node', ['scripts/serve.mjs'], { cwd: ROOT, env: { ...process.env, PORT: String(PORT2), BASE_PATH: SUB } });
await new Promise((r) => setTimeout(r, 700));
const sp = await ctx.newPage(); const bad = [];
sp.on('response', (r) => { if (r.url().includes(`:${PORT2}`) && r.status() >= 400) bad.push(`${r.status()} ${r.url()}`); });
await sp.goto(`http://localhost:${PORT2}${SUB}/`); await sp.waitForURL(/\/zoomania\/en\/index\.html/);
for (const lang of ['en', 'ar']) for (const p of pages) { await sp.goto(`http://localhost:${PORT2}${SUB}/${lang}/${p}.html`, { waitUntil: 'load' }); }
ok(bad.length === 0, `GitHub Pages sub-path ${SUB}/: all 8 pages and assets load ${bad.join(' | ')}`);
srv2.kill();
await browser.close(); srv.kill();
console.log(fails ? `\n${fails} check(s) failed` : '\nAll browser checks passed');
process.exit(fails ? 1 : 0);
