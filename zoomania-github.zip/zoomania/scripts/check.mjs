// Static checks on ./docs: page set, internal links & anchors, SEO tags, colour contrast.
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import path from 'node:path';
const DIST = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../docs');
let fails = 0; const ok = (c, m) => { console.log(`${c ? '✓' : '✗'} ${m}`); if (!c) fails++; };

const html = fs.readdirSync(DIST, { recursive: true }).filter((f) => f.endsWith('.html')).sort();
const expected = ['ar/breeds.html', 'ar/dubai.html', 'ar/index.html', 'ar/quiz.html', 'en/breeds.html', 'en/dubai.html', 'en/index.html', 'en/quiz.html', 'index.html'];
ok(JSON.stringify(html) === JSON.stringify(expected), `exactly 8 content pages + root redirect (${html.length} HTML files)`);

const ids = {};
for (const f of html) ids[f] = new Set([...fs.readFileSync(path.join(DIST, f), 'utf8').matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]));
let links = 0, broken = [];
for (const f of html) {
  const src = fs.readFileSync(path.join(DIST, f), 'utf8');
  for (const [, attr] of src.matchAll(/(?:href|src)="([^"]+)"/g)) {
    if (/^(https?:|mailto:|tel:|data:)/.test(attr)) continue;
    links++;
    const [p, hash] = attr.split('#');
    const target = p ? path.normalize(path.join(path.dirname(f), p)) : f;
    if (!fs.existsSync(path.join(DIST, target))) { broken.push(`${f} → ${attr}`); continue; }
    if (hash && target.endsWith('.html') && !ids[target]?.has(hash)) broken.push(`${f} → #${hash} missing`);
  }
  if (f !== 'index.html') {
    ok(/<link rel="canonical"/.test(src) && (src.match(/hreflang=/g) || []).length >= 3 && /og:image/.test(src) && /application\/ld\+json/.test(src), `${f} has canonical, hreflang, Open Graph and JSON-LD`);
  }
}
ok(broken.length === 0, `${links} internal links/assets resolve${broken.length ? ': ' + broken.join(', ') : ''}`);
for (const f of ['sitemap.xml', 'robots.txt', 'site.webmanifest', 'assets/brand/favicon.svg', 'assets/brand/favicon-32.png', 'assets/brand/apple-touch-icon.png', 'assets/brand/og-image.png', 'assets/brand/logo-horizontal.png', 'assets/brand/logo.png', 'assets/brand/logo-light.png'])
  ok(fs.existsSync(path.join(DIST, f)), `${f} exists`);

// WCAG contrast
const lum = (hex) => { const c = hex.match(/\w\w/g).map((x) => parseInt(x, 16) / 255).map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
const ratio = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((m, n) => n - m); return (x + 0.05) / (y + 0.05); };
const bgs = { 'Blush #FFCED8': 'FFCED8', 'Soft Pink #FFDDDD': 'FFDDDD', 'Cream #FFF4DE': 'FFF4DE', 'Peach #FFE8C4': 'FFE8C4' };
for (const [fgName, fg, min] of [['Ink #30292D', '30292D', 4.5], ['Ink-soft #4E4449', '4E4449', 4.5], ['Rose #8A3550', '8A3550', 4.5]])
  for (const [bn, bg] of Object.entries(bgs)) { const r = ratio(fg, bg); ok(r >= min, `${fgName} on ${bn}: ${r.toFixed(2)}:1 (≥ ${min})`); }
for (const [n, a, b, min] of [['Cream text on Ink buttons/footer', 'FFF4DE', '30292D', 4.5], ['Blush footer headings on Ink', 'FFCED8', '30292D', 4.5], ['Footer body #F3E7DA on Ink', 'F3E7DA', '30292D', 4.5], ['Meter fill Rose on Soft Pink (UI)', '8A3550', 'FFDDDD', 3]])
  { const r = ratio(a, b); ok(r >= min, `${n}: ${r.toFixed(2)}:1 (≥ ${min})`); }

console.log(fails ? `\n${fails} static check(s) failed` : '\nAll static checks passed');
process.exit(fails ? 1 : 0);
