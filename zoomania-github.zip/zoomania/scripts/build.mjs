// ZOOMANIA static build: generates 8 independent HTML pages (4 EN + 4 AR),
// a root redirect, brand assets, sitemap, robots and manifest into ./docs
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import path from 'node:path';
import sharp from 'sharp';
import opentype from 'opentype.js';
import en from '../src/content/en.mjs';
import ar from '../src/content/ar.mjs';
import { page } from '../src/templates/layout.mjs';
import { homeBody, breedsBody, quizBody, dubaiBody } from '../src/templates/pages.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DIST = path.join(ROOT, 'docs');
// Public site address, used for canonical URLs, hreflang, Open Graph and the sitemap.
// Priority: SITE_URL environment variable → --site=<url> argument → "siteUrl" in zoomania.config.json.
const cfgFile = path.join(ROOT, 'zoomania.config.json');
const cfg = fs.existsSync(cfgFile) ? JSON.parse(fs.readFileSync(cfgFile, 'utf8')) : {};
const argSite = process.argv.find((a) => a.startsWith('--site='))?.slice(7);
const SITE = (process.env.SITE_URL || argSite || cfg.siteUrl || 'https://zoomania.example').replace(/\/$/, '');
if (SITE.includes('zoomania.example')) console.warn('⚠  Site URL is still the placeholder — set "siteUrl" in zoomania.config.json before publishing.');
console.log(`Site URL: ${SITE}`);

fs.rmSync(DIST, { recursive: true, force: true });
const mk = (p) => fs.mkdirSync(p, { recursive: true });
const write = (rel, data) => { const f = path.join(DIST, rel); mk(path.dirname(f)); fs.writeFileSync(f, data); };
const copyDir = (from, to) => { if (!fs.existsSync(from)) return; mk(to); for (const f of fs.readdirSync(from)) { const s = path.join(from, f), d = path.join(to, f); fs.statSync(s).isDirectory() ? copyDir(s, d) : fs.copyFileSync(s, d); } };

/* ---------- Brand assets (official ZOOMANIA artwork in src/assets/brand-source) ---------- */
const BS = (f) => path.join(ROOT, 'src/assets/brand-source', f);
const fontFile = path.join(ROOT, 'node_modules/@fontsource/plus-jakarta-sans/files/plus-jakarta-sans-latin-700-normal.woff');
const font = opentype.parse(fs.readFileSync(fontFile).buffer.slice(0));
function textPath(txt, x, y, size) { // manual glyph layout (avoids unsupported shaping features)
  const scale = size / font.unitsPerEm; let cx = x, d = '', prev = null;
  for (const ch of txt) { const g = font.charToGlyph(ch); if (prev) cx += font.getKerningValue(prev, g) * scale; d += g.getPath(cx, y, size).toPathData(2); cx += g.advanceWidth * scale; prev = g; }
  return d;
}
const textWidth = (txt, size) => [...txt].reduce((w, ch) => w + font.charToGlyph(ch).advanceWidth, 0) * size / font.unitsPerEm;
const OG_LINE = 'Discover the wonderful world of cats';
const png = (input, opts = {}) => sharp(input).resize(opts.w, opts.h, { fit: 'contain', background: opts.bg || { r: 0, g: 0, b: 0, alpha: 0 } }).png({ compressionLevel: 9 }).toBuffer();

write('assets/brand/logo.png', await png(BS('logo.png'), { w: 600 }));
write('assets/brand/logo-light.png', await png(BS('logo-light.png'), { w: 600 }));
write('assets/brand/logo-horizontal.png', await png(BS('logo.png'), { w: 1200 }));
write('assets/brand/cat-icon.png', await png(BS('icon.png'), { w: 512, h: 512 }));
write('assets/brand/icon-512.png', await png(BS('icon.png'), { w: 512, h: 512 }));
write('assets/brand/icon-192.png', await png(BS('icon.png'), { w: 192, h: 192 }));
write('assets/brand/apple-touch-icon.png', await sharp(BS('icon.png')).resize(150, 150).extend({ top: 15, bottom: 15, left: 15, right: 15, background: '#FFF4DE' }).flatten({ background: '#FFF4DE' }).png().toBuffer());
const fav32 = await png(BS('favicon.png'), { w: 32, h: 32 });
write('assets/brand/favicon-32.png', fav32);
const fav64 = await png(BS('icon.png'), { w: 64, h: 64 });
write('assets/brand/favicon.svg', `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 64 64" width="64" height="64"><image width="64" height="64" href="data:image/png;base64,${fav64.toString('base64')}"/></svg>`);
const ogLogo = await png(BS('logo.png'), { w: 900 });
const ogBg = `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFF4DE"/><stop offset=".55" stop-color="#FFE8C4"/><stop offset="1" stop-color="#FFCED8"/></linearGradient></defs>
<rect width="1200" height="630" fill="url(#g)"/><circle cx="1060" cy="90" r="190" fill="#FFDDDD"/><circle cx="120" cy="590" r="150" fill="#FFCED8"/>
<path d="${textPath(OG_LINE, (1200 - textWidth(OG_LINE, 44)) / 2, 480, 44)}" fill="#30292D"/></svg>`;
const meta = await sharp(ogLogo).metadata();
write('assets/brand/og-image.png', await sharp(Buffer.from(ogBg)).composite([{ input: ogLogo, top: 140, left: Math.round((1200 - meta.width) / 2) }]).png().toBuffer());

/* ---------- Static assets ---------- */
copyDir(path.join(ROOT, 'src/assets/css'), path.join(DIST, 'assets/css'));
copyDir(path.join(ROOT, 'src/assets/js'), path.join(DIST, 'assets/js'));
copyDir(path.join(ROOT, 'src/assets/photos'), path.join(DIST, 'assets/photos'));
copyDir(path.join(ROOT, 'src/assets/images'), path.join(DIST, 'assets/images'));

/* ---------- Pages ---------- */
const bodies = { index: homeBody, breeds: breedsBody, quiz: quizBody, dubai: dubaiBody };
const scripts = { breeds: ['breeds.js'], quiz: ['quiz.js'] };

for (const t of [en, ar]) {
  for (const name of Object.keys(bodies)) {
    const m = t.meta[name === 'index' ? 'home' : name];
    const url = `${SITE}/${t.lang}/${name}.html`;
    const jsonld = [{ '@context': 'https://schema.org', '@type': 'WebPage', name: m.title, description: m.desc, url, inLanguage: t.lang,
      isPartOf: { '@type': 'WebSite', name: 'ZOOMANIA', url: `${SITE}/` } }];
    if (name === 'index') jsonld.push({ '@context': 'https://schema.org', '@type': 'Organization', name: 'ZOOMANIA', url: `${SITE}/`, logo: `${SITE}/assets/brand/icon-512.png`, founder: { '@type': 'Person', name: 'Atrin' } });
    const faqs = name === 'breeds' ? t.care.faq : name === 'dubai' ? t.dubai.s6.faq : null;
    if (faqs) jsonld.push({ '@context': 'https://schema.org', '@type': 'FAQPage', inLanguage: t.lang,
      mainEntity: faqs.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) });
    write(`${t.lang}/${name}.html`, page(t, name, bodies[name](t), { site: SITE, jsonld, scripts: scripts[name] }));
  }
}

/* ---------- Root redirect (not a content page) ---------- */
write('index.html', `<!DOCTYPE html>
<html lang="en" dir="ltr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>ZOOMANIA</title><meta name="robots" content="noindex, follow">
<link rel="canonical" href="${SITE}/en/index.html"><meta http-equiv="refresh" content="0; url=en/index.html">
<link rel="icon" href="assets/brand/favicon.svg" type="image/svg+xml">
<script>location.replace('en/index.html' + location.hash);</script>
<style>body{font-family:system-ui,sans-serif;background:#FFF4DE;color:#30292D;display:grid;place-items:center;min-height:100vh;margin:0}a{color:#30292D}</style>
</head><body><p>Redirecting to <a href="en/index.html">ZOOMANIA (English)</a> · <a href="ar/index.html" lang="ar">زومانيا (العربية)</a></p></body></html>`);

/* ---------- SEO files ---------- */
const today = new Date().toISOString().slice(0, 10);
write('sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">
${['en', 'ar'].flatMap((l) => Object.keys(bodies).map((n) => `  <url><loc>${SITE}/${l}/${n}.html</loc><lastmod>${today}</lastmod>
    <xhtml:link rel="alternate" hreflang="en" href="${SITE}/en/${n}.html"/><xhtml:link rel="alternate" hreflang="ar" href="${SITE}/ar/${n}.html"/><xhtml:link rel="alternate" hreflang="x-default" href="${SITE}/en/${n}.html"/></url>`)).join('\n')}
</urlset>
`);
write('.nojekyll', '');
write('robots.txt', `User-agent: *\nAllow: /\n\nSitemap: ${SITE}/sitemap.xml\n`);
write('site.webmanifest', JSON.stringify({ name: 'ZOOMANIA', short_name: 'zoomania', start_url: 'en/index.html', display: 'standalone', background_color: '#FFF4DE', theme_color: '#FFCED8',
  icons: [{ src: 'assets/brand/icon-192.png', sizes: '192x192', type: 'image/png' }, { src: 'assets/brand/icon-512.png', sizes: '512x512', type: 'image/png' }] }, null, 2));

const html = fs.readdirSync(DIST, { recursive: true }).filter((f) => f.endsWith('.html'));
console.log(`✓ Built ${html.length} HTML files into docs/:`, html.sort().join(', '));
